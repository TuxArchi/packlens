(function() {
	// src/core/json-extract.ts
	/**
	* YouTube embeds its bootstrap state as `var ytInitialPlayerResponse = {...};`
	* inside a <script> tag. The value is a JSON literal, so we can locate the
	* opening brace and walk to its matching closing brace while respecting
	* strings and escapes. This avoids brittle regular expressions.
	*/
	function extractJsonObject(source, marker) {
		const markerAt = source.indexOf(marker);
		if (markerAt === -1) return null;
		const start = source.indexOf("{", markerAt + marker.length);
		if (start === -1) return null;
		let depth = 0;
		let inString = false;
		let escaped = false;
		for (let i = start; i < source.length; i += 1) {
			const char = source[i];
			if (inString) {
				if (escaped) escaped = false;
				else if (char === "\\") escaped = true;
				else if (char === "\"") inString = false;
				continue;
			}
			if (char === "\"") inString = true;
			else if (char === "{") depth += 1;
			else if (char === "}") {
				depth -= 1;
				if (depth === 0) try {
					return JSON.parse(source.slice(start, i + 1));
				} catch {
					return null;
				}
			}
		}
		return null;
	}
	// src/core/view-count.ts
	var SUFFIXES = {
		k: 1e3,
		thousand: 1e3,
		mil: 1e3,
		m: 1e6,
		million: 1e6,
		millones: 1e6,
		millon: 1e6,
		millón: 1e6,
		b: 1e9,
		billion: 1e9
	};
	/**
	* Parses both exact ("619,847 views") and compact ("1.2M views", "114 mil")
	* view counts. The long suffixes are matched before the one-letter ones so
	* "114 mil" is not read as 114 million.
	*/
	function parseViewCount(text) {
		if (!text) return 0;
		const match = text.replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim().match(/(\d[\d.,\s]*)\s*(thousand|million|billion|millones|millón|millon|mil|k|m|b)?/i);
		if (!match) return 0;
		const rawNumber = match[1].replace(/\s/g, "");
		const suffix = (match[2] ?? "").toLocaleLowerCase();
		if (suffix) {
			const number = Number(rawNumber.replace(/,/g, "."));
			if (!Number.isFinite(number)) return 0;
			return Math.round(number * (SUFFIXES[suffix] ?? 1));
		}
		const digits = rawNumber.replace(/[^\d]/g, "");
		return digits ? Number(digits) : 0;
	}
	// src/core/channel-page.ts
	function runsText$1(value) {
		if (!value) return "";
		if (typeof value.simpleText === "string") return value.simpleText;
		if (Array.isArray(value.runs)) return value.runs.map((run) => typeof run?.text === "string" ? run.text : "").join("");
		return "";
	}
	function legacyVideo(node) {
		const videoId = typeof node?.videoId === "string" ? node.videoId : "";
		const title = runsText$1(node?.title);
		const views = parseViewCount(runsText$1(node?.viewCountText));
		if (!videoId || !title || views <= 0) return null;
		return {
			videoId,
			title,
			views
		};
	}
	/**
	* Parses the channel's /videos page. YouTube's 2026 UI uses `lockupViewModel`
	* items; older layouts still use `videoRenderer` or `gridVideoRenderer`.
	* The page is fetched with `hl=en` so compact view counts share one format.
	*/
	function parseChannelPage(html) {
		if (!html || !html.includes("ytInitialData")) return null;
		const parsed = extractJsonObject(html, "ytInitialData");
		if (!parsed || typeof parsed !== "object") return null;
		const data = parsed;
		const meta = data.metadata?.channelMetadataRenderer;
		const channelId = typeof meta?.externalId === "string" ? meta.externalId : "";
		const channelName = typeof meta?.title === "string" ? meta.title : "";
		const videos = /* @__PURE__ */ new Map();
		const visit = (node, depth = 0) => {
			if (!node || typeof node !== "object" || depth > 30) return;
			if (Array.isArray(node)) {
				for (const item of node) visit(item, depth + 1);
				return;
			}
			if (node.lockupViewModel) {
				const lockup = node.lockupViewModel;
				const videoId = typeof lockup.contentId === "string" ? lockup.contentId : "";
				const title = lockup.metadata?.lockupMetadataViewModel?.title?.content;
				const rows = lockup.metadata?.lockupMetadataViewModel?.metadata?.contentMetadataViewModel?.metadataRows;
				const parts = Array.isArray(rows) && rows[0] && Array.isArray(rows[0].metadataParts) ? rows[0].metadataParts : [];
				let viewsText = "";
				for (const part of parts) {
					const label = typeof part?.accessibilityLabel === "string" ? part.accessibilityLabel : "";
					const text = typeof part?.text?.content === "string" ? part.text.content : "";
					if (part?.leadingIcon?.name === "PLAY_ARROW_OUTLINED" || /views|visualizaciones|vistas/i.test(label)) {
						viewsText = text || label;
						break;
					}
				}
				const views = parseViewCount(viewsText);
				if (videoId && typeof title === "string" && title && views > 0) videos.set(videoId, {
					videoId,
					title,
					views
				});
			}
			const legacy = node.videoRenderer ?? node.gridVideoRenderer;
			if (legacy) {
				const video = legacyVideo(legacy);
				if (video) videos.set(video.videoId, video);
			}
			for (const key of Object.keys(node)) visit(node[key], depth + 1);
		};
		visit(data.contents);
		return {
			channelId,
			channelName,
			videos: [...videos.values()]
		};
	}
	// src/core/image-metrics.ts
	var MOBILE_WIDTH = 168;
	var EDGE_MAGNITUDE = 160;
	function percentile(sorted, ratio) {
		if (sorted.length === 0) return 0;
		return sorted[Math.min(sorted.length - 1, Math.max(0, Math.round((sorted.length - 1) * ratio)))];
	}
	function downscale(lum, width, height, targetWidth) {
		const scale = Math.min(1, targetWidth / width);
		const outWidth = Math.max(1, Math.round(width * scale));
		const outHeight = Math.max(1, Math.round(height * scale));
		const out = new Float32Array(outWidth * outHeight);
		const xRatio = width / outWidth;
		const yRatio = height / outHeight;
		for (let y = 0; y < outHeight; y += 1) {
			const y0 = Math.floor(y * yRatio);
			const y1 = Math.min(height, Math.max(y0 + 1, Math.floor((y + 1) * yRatio)));
			for (let x = 0; x < outWidth; x += 1) {
				const x0 = Math.floor(x * xRatio);
				const x1 = Math.min(width, Math.max(x0 + 1, Math.floor((x + 1) * xRatio)));
				let sum = 0;
				let count = 0;
				for (let yy = y0; yy < y1; yy += 1) for (let xx = x0; xx < x1; xx += 1) {
					sum += lum[yy * width + xx];
					count += 1;
				}
				out[y * outWidth + x] = count > 0 ? sum / count : 0;
			}
		}
		return {
			lum: out,
			width: outWidth,
			height: outHeight
		};
	}
	function laplacianVariance(lum, width, height) {
		let sum = 0;
		let squareSum = 0;
		let count = 0;
		for (let y = 1; y < height - 1; y += 1) for (let x = 1; x < width - 1; x += 1) {
			const i = y * width + x;
			const value = 4 * lum[i] - lum[i - 1] - lum[i + 1] - lum[i - width] - lum[i + width];
			sum += value;
			squareSum += value * value;
			count += 1;
		}
		if (count === 0) return 0;
		const mean = sum / count;
		return Math.max(0, squareSum / count - mean * mean);
	}
	function computeThumbMetrics(image) {
		const { data, width, height } = image;
		const pixelCount = width * height;
		if (pixelCount === 0) return {
			width,
			height,
			luminanceMean: 0,
			luminanceStd: 0,
			tonalRange: 0,
			edgeDensity: 0,
			colorfulness: 0,
			saturationMean: 0,
			mobileRange: 0,
			mobileRetention: 0,
			mobileSharpness: 0
		};
		const lum = new Float32Array(pixelCount);
		let luminanceSum = 0;
		let saturationSum = 0;
		let rgSum = 0;
		let rgSquareSum = 0;
		let ybSum = 0;
		let ybSquareSum = 0;
		for (let i = 0, p = 0; i < pixelCount; i += 1, p += 4) {
			const r = data[p];
			const g = data[p + 1];
			const b = data[p + 2];
			const l = .2126 * r + .7152 * g + .0722 * b;
			lum[i] = l;
			luminanceSum += l;
			const max = Math.max(r, g, b);
			saturationSum += max === 0 ? 0 : (max - Math.min(r, g, b)) / max;
			const rg = r - g;
			const yb = .5 * (r + g) - b;
			rgSum += rg;
			rgSquareSum += rg * rg;
			ybSum += yb;
			ybSquareSum += yb * yb;
		}
		const luminanceMean = luminanceSum / pixelCount;
		let varianceSum = 0;
		for (let i = 0; i < pixelCount; i += 1) {
			const delta = lum[i] - luminanceMean;
			varianceSum += delta * delta;
		}
		const luminanceStd = Math.sqrt(varianceSum / pixelCount);
		const sorted = Float32Array.from(lum).sort();
		const tonalRange = Math.max(0, percentile(sorted, .95) - percentile(sorted, .05));
		const rgMean = rgSum / pixelCount;
		const ybMean = ybSum / pixelCount;
		const rgVariance = Math.max(0, rgSquareSum / pixelCount - rgMean * rgMean);
		const ybVariance = Math.max(0, ybSquareSum / pixelCount - ybMean * ybMean);
		const colorfulness = Math.sqrt(rgVariance + ybVariance) + .3 * Math.sqrt(rgMean * rgMean + ybMean * ybMean);
		let edgePixels = 0;
		let edgeSamples = 0;
		for (let y = 1; y < height - 1; y += 1) for (let x = 1; x < width - 1; x += 1) {
			const i = y * width + x;
			const gx = lum[i - width + 1] + 2 * lum[i + 1] + lum[i + width + 1] - (lum[i - width - 1] + 2 * lum[i - 1] + lum[i + width - 1]);
			const gy = lum[i + width - 1] + 2 * lum[i + width] + lum[i + width + 1] - (lum[i - width - 1] + 2 * lum[i - width] + lum[i - width + 1]);
			if (Math.abs(gx) + Math.abs(gy) > EDGE_MAGNITUDE) edgePixels += 1;
			edgeSamples += 1;
		}
		const edgeDensity = edgeSamples > 0 ? edgePixels / edgeSamples : 0;
		const mobile = downscale(lum, width, height, MOBILE_WIDTH);
		const mobileSorted = Float32Array.from(mobile.lum).sort();
		const mobileRange = Math.max(0, percentile(mobileSorted, .95) - percentile(mobileSorted, .05));
		const mobileRetention = tonalRange > 1 ? Math.min(1.5, mobileRange / tonalRange) : 0;
		return {
			width,
			height,
			luminanceMean,
			luminanceStd,
			tonalRange,
			edgeDensity,
			colorfulness,
			saturationMean: saturationSum / pixelCount,
			mobileRange,
			mobileRetention,
			mobileSharpness: laplacianVariance(mobile.lum, mobile.width, mobile.height)
		};
	}
	// src/core/score.ts
	function clamp(value, min, max) {
		if (!Number.isFinite(value)) return min;
		return Math.min(max, Math.max(min, value));
	}
	// src/core/tags.ts
	function tagCharacters(tags) {
		return tags.join(",").length;
	}
	// src/core/seo.ts
	var STOPWORDS = /* @__PURE__ */ new Set([
		"el",
		"la",
		"los",
		"las",
		"un",
		"una",
		"unos",
		"unas",
		"de",
		"del",
		"al",
		"en",
		"con",
		"por",
		"para",
		"y",
		"o",
		"que",
		"se",
		"su",
		"sus",
		"tu",
		"tus",
		"mi",
		"mis",
		"es",
		"son",
		"como",
		"the",
		"a",
		"an",
		"of",
		"in",
		"on",
		"with",
		"for",
		"and",
		"or",
		"to",
		"my",
		"your",
		"this",
		"that",
		"is",
		"are",
		"it",
		"how",
		"what",
		"why"
	]);
	function fold(text) {
		return text.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase();
	}
	// src/core/recommendations.ts
	function tokenize(title) {
		return title.split(/[^\p{L}\p{N}]+/u).map((word) => fold(word)).filter((word) => word.length > 2 && !STOPWORDS.has(word));
	}
	/**
	* Turns the top results into actionable patterns: repeated phrases in titles,
	* title structure and a grounded set of suggested tags.
	*/
	function analyzeCompetition(keyword, videos) {
		const phraseStats = /* @__PURE__ */ new Map();
		for (const video of videos) {
			const words = tokenize(video.title);
			const candidates = /* @__PURE__ */ new Set();
			for (let index = 0; index < words.length; index += 1) {
				candidates.add(words[index]);
				if (index + 1 < words.length) candidates.add(`${words[index]} ${words[index + 1]}`);
			}
			for (const phrase of candidates) {
				const entry = phraseStats.get(phrase) ?? {
					count: 0,
					views: 0
				};
				entry.count += 1;
				entry.views += video.views;
				phraseStats.set(phrase, entry);
			}
		}
		const phrases = [...phraseStats.entries()].filter(([, stats]) => stats.count >= 2).sort((a, b) => b[1].count - a[1].count || b[1].views - a[1].views).slice(0, 6).map(([text, stats]) => ({
			text,
			count: stats.count
		}));
		const foldedKeyword = fold(keyword).trim();
		const withNumber = videos.filter((video) => /\d/.test(video.title)).length;
		const keywordAtStart = foldedKeyword ? videos.filter((video) => fold(video.title).trim().startsWith(foldedKeyword)).length : 0;
		const withYear = videos.filter((video) => /20\d{2}/.test(video.title)).length;
		const averageLength = videos.length > 0 ? Math.round(videos.reduce((sum, video) => sum + Array.from(video.title).length, 0) / videos.length) : 0;
		const suggestedTags = [];
		const seen = /* @__PURE__ */ new Set();
		for (const candidate of [keyword, ...phrases.map((phrase) => phrase.text)]) {
			const tag = candidate.replace(/\s+/g, " ").trim();
			if (!tag) continue;
			const key = fold(tag);
			if (seen.has(key)) continue;
			seen.add(key);
			if (tagCharacters([...suggestedTags, tag]) > 480) break;
			suggestedTags.push(tag);
			if (suggestedTags.length >= 15) break;
		}
		return {
			phrases,
			patterns: {
				withNumber,
				keywordAtStart,
				withYear,
				averageLength
			},
			suggestedTags
		};
	}
	// src/core/stats.ts
	function median(values) {
		if (values.length === 0) return 0;
		const sorted = [...values].sort((a, b) => a - b);
		const middle = Math.floor(sorted.length / 2);
		return sorted.length % 2 === 1 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
	}
	// src/core/keywords.ts
	var THIRTY_DAYS = 2592e6;
	function keywordLabel(difficulty) {
		if (difficulty <= 30) return "easy";
		if (difficulty <= 60) return "medium";
		return "hard";
	}
	function computeKeywordResult(keyword, videos, options = {}) {
		const mode = options.mode ?? "api";
		const subsAvailable = options.subsAvailable ?? true;
		const medianViews = median(videos.map((video) => video.views));
		const medianSubs = subsAvailable ? median(videos.map((video) => video.subs)) : 0;
		const now = Date.now();
		const recent = videos.filter((video) => {
			if (typeof video.publishedDaysAgo === "number" && Number.isFinite(video.publishedDaysAgo)) return video.publishedDaysAgo <= 30;
			const time = Date.parse(video.publishedAt);
			return Number.isFinite(time) && time >= now - THIRTY_DAYS;
		}).length;
		const recentRatio = videos.length > 0 ? recent / videos.length : 0;
		const titleMatches = videos.filter((video) => fold(video.title).includes(fold(keyword))).length;
		const titleMatchRatio = videos.length > 0 ? titleMatches / videos.length : 0;
		const subScore = subsAvailable ? clamp((Math.log10(Math.max(medianSubs, 1)) - 3) / 3 * 100, 0, 100) : 0;
		const viewScore = clamp((Math.log10(Math.max(medianViews, 1)) - 3) / 4 * 100, 0, 100);
		const difficulty = subsAvailable ? Math.round(clamp(subScore * .55 + viewScore * .3 + titleMatchRatio * 100 * .15, 0, 100)) : Math.round(clamp(viewScore * .7 + titleMatchRatio * 100 * .2 + recentRatio * 100 * .1, 0, 100));
		const interestView = clamp((Math.log10(Math.max(medianViews, 1)) - 2) / 5 * 100, 0, 100);
		const interest = Math.round(clamp(interestView * .85 + recentRatio * 100 * .15, 0, 100));
		return {
			keyword,
			difficulty,
			label: keywordLabel(difficulty),
			interest,
			medianViews,
			medianSubs,
			recentRatio,
			titleMatchRatio,
			top: videos,
			mode,
			subsAvailable,
			recommendations: analyzeCompetition(keyword, videos)
		};
	}
	// src/core/outliers.ts
	function computeOutliers(videos) {
		const medianViews = median(videos.map((video) => video.views));
		const enriched = videos.map((video) => ({
			...video,
			outlier: medianViews > 0 ? video.views / medianViews : 0
		}));
		enriched.sort((a, b) => b.outlier - a.outlier);
		return {
			medianViews,
			videos: enriched
		};
	}
	// src/core/player.ts
	function asString(value) {
		return typeof value === "string" ? value : "";
	}
	function asNumber(value) {
		if (typeof value === "number" && Number.isFinite(value)) return value;
		if (typeof value === "string" && value.trim() !== "") {
			const parsed = Number(value);
			if (Number.isFinite(parsed)) return parsed;
		}
		return null;
	}
	function normalizeRawVideo(input) {
		if (!input || typeof input !== "object") return null;
		const raw = input;
		const videoId = asString(raw.videoId);
		if (!videoId) return null;
		const keywords = Array.isArray(raw.keywords) ? raw.keywords.filter((keyword) => typeof keyword === "string").map((keyword) => keyword.trim()).filter(Boolean) : [];
		const thumbnails = Array.isArray(raw.thumbnails) ? raw.thumbnails.filter((url) => typeof url === "string").map((url) => url.trim()).filter(Boolean) : [];
		return {
			videoId,
			title: asString(raw.title),
			keywords,
			viewCount: asNumber(raw.viewCount),
			lengthSeconds: asNumber(raw.lengthSeconds),
			channel: asString(raw.channel),
			description: asString(raw.description),
			thumbnails,
			publishedAt: typeof raw.publishedAt === "string" ? raw.publishedAt : null,
			category: typeof raw.category === "string" ? raw.category : null
		};
	}
	function toVideoData(raw, source) {
		const byId = raw.videoId ? `https://i.ytimg.com/vi/${raw.videoId}/maxresdefault.jpg` : null;
		const lastThumbnail = raw.thumbnails.length > 0 ? raw.thumbnails[raw.thumbnails.length - 1] : null;
		return {
			source,
			videoId: raw.videoId || null,
			title: raw.title,
			thumbnailUrl: byId ?? lastThumbnail,
			channel: raw.channel || null,
			views: raw.viewCount,
			publishedAt: raw.publishedAt,
			lengthSeconds: raw.lengthSeconds,
			tags: raw.keywords,
			description: raw.description,
			category: raw.category
		};
	}
	var UNIT_LIMIT = 1e4;
	var STORAGE_KEY = "quota";
	/**
	* Google resets the YouTube Data API quota at midnight Pacific Time, so the
	* local counter must use the same day boundary.
	*/
	function todayPT() {
		try {
			const parts = new Intl.DateTimeFormat("en-US", {
				timeZone: "America/Los_Angeles",
				year: "numeric",
				month: "2-digit",
				day: "2-digit"
			}).formatToParts(/* @__PURE__ */ new Date());
			const get = (type) => parts.find((part) => part.type === type)?.value ?? "";
			return `${get("year")}-${get("month")}-${get("day")}`;
		} catch {
			return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
		}
	}
	async function readRecord() {
		try {
			const record = (await browser.storage.local.get(STORAGE_KEY))[STORAGE_KEY];
			if (record && record.date === todayPT() && typeof record.searches === "number" && typeof record.units === "number") return {
				date: record.date,
				searches: Math.max(0, record.searches),
				units: Math.max(0, record.units)
			};
		} catch {}
		return {
			date: todayPT(),
			searches: 0,
			units: 0
		};
	}
	async function writeRecord(record) {
		await browser.storage.local.set({ [STORAGE_KEY]: record });
	}
	async function getQuota() {
		const record = await readRecord();
		const searchesLeft = Math.max(0, 100 - record.searches);
		const unitsLeft = Math.max(0, UNIT_LIMIT - record.units);
		return {
			date: record.date,
			searchesUsed: record.searches,
			searchLimit: 100,
			searchesLeft,
			unitsUsed: record.units,
			unitLimit: UNIT_LIMIT,
			unitsLeft
		};
	}
	async function addSearch() {
		const record = await readRecord();
		await writeRecord({
			date: todayPT(),
			searches: record.searches + 1,
			units: record.units
		});
	}
	async function addUnits(units) {
		const record = await readRecord();
		await writeRecord({
			date: todayPT(),
			searches: record.searches,
			units: record.units + Math.max(0, units)
		});
	}
	/** A search needs one search-list call and two unit-priced detail calls. */
	function canSearch(quota) {
		return quota.searchesLeft > 0 && quota.unitsLeft >= 2;
	}
	// src/core/search-page.ts
	function runsText(value) {
		if (!value) return "";
		if (typeof value.simpleText === "string") return value.simpleText;
		if (Array.isArray(value.runs)) return value.runs.map((run) => typeof run?.text === "string" ? run.text : "").join("");
		return "";
	}
	function parseDurationText(text) {
		const parts = text.trim().split(":").map((part) => Number(part));
		if (parts.length === 0 || parts.some((part) => !Number.isFinite(part))) return 0;
		if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
		if (parts.length === 2) return parts[0] * 60 + parts[1];
		return 0;
	}
	var UNIT_DAYS = {
		second: 0,
		s: 0,
		minute: 1 / 1440,
		m: 1 / 1440,
		hour: 1 / 24,
		h: 1 / 24,
		day: 1,
		d: 1,
		week: 7,
		w: 7,
		month: 30,
		mo: 30,
		year: 365,
		y: 365
	};
	/**
	* YouTube shows relative dates ("yesterday", "2mo ago", "hace 3 semanas").
	* We only need an approximate age to compute how recent the top results are.
	*/
	function parseRelativeAgeDays(text) {
		const value = text.trim().toLocaleLowerCase();
		if (!value) return null;
		if (/just now|right now|ahora mismo/.test(value)) return 0;
		if (/yesterday|ayer/.test(value)) return 1;
		const english = value.match(/(\d+)\s*(second|minute|hour|day|week|month|year|mo|s|m|h|d|w|y)s?\s+ago/);
		if (english) return Number(english[1]) * (UNIT_DAYS[english[2]] ?? 0);
		const spanish = value.match(/hace\s+(\d+)\s+(segundo|minuto|hora|día|dia|semana|mes|año|ano)s?/);
		if (spanish) {
			const unit = spanish[2];
			if (unit.startsWith("segundo")) return 0;
			if (unit.startsWith("minuto")) return Number(spanish[1]) / 1440;
			if (unit.startsWith("hora")) return Number(spanish[1]) / 24;
			if (unit.startsWith("día") || unit.startsWith("dia")) return Number(spanish[1]);
			if (unit.startsWith("semana")) return Number(spanish[1]) * 7;
			if (unit.startsWith("mes")) return Number(spanish[1]) * 30;
			return Number(spanish[1]) * 365;
		}
		return null;
	}
	/**
	* Parses the public search results page. YouTube's 2026 search still uses
	* `videoRenderer`; `lockupViewModel` is handled as a fallback for newer UIs.
	*/
	function parseSearchPage(html) {
		if (!html || !html.includes("ytInitialData")) return null;
		const parsed = extractJsonObject(html, "ytInitialData");
		if (!parsed || typeof parsed !== "object") return null;
		const data = parsed;
		const videos = /* @__PURE__ */ new Map();
		const visit = (node, depth = 0) => {
			if (!node || typeof node !== "object" || depth > 30) return;
			if (Array.isArray(node)) {
				for (const item of node) visit(item, depth + 1);
				return;
			}
			if (node.videoRenderer) {
				const video = node.videoRenderer;
				const videoId = typeof video.videoId === "string" ? video.videoId : "";
				const title = runsText(video.title);
				const views = parseViewCount(runsText(video.viewCountText));
				if (videoId && title && views > 0) videos.set(videoId, {
					videoId,
					title,
					channelTitle: runsText(video.ownerText) || runsText(video.longBylineText),
					views,
					publishedText: runsText(video.publishedTimeText),
					durationSeconds: parseDurationText(runsText(video.lengthText))
				});
			}
			if (node.lockupViewModel) {
				const lockup = node.lockupViewModel;
				const videoId = typeof lockup.contentId === "string" ? lockup.contentId : "";
				const title = lockup.metadata?.lockupMetadataViewModel?.title?.content;
				const rows = lockup.metadata?.lockupMetadataViewModel?.metadata?.contentMetadataViewModel?.metadataRows;
				const parts = Array.isArray(rows) && rows[0] && Array.isArray(rows[0].metadataParts) ? rows[0].metadataParts : [];
				let viewsText = "";
				let channelTitle = "";
				let publishedText = "";
				for (const part of parts) {
					const text = typeof part?.text?.content === "string" ? part.text.content : "";
					const label = typeof part?.accessibilityLabel === "string" ? part.accessibilityLabel : "";
					if (part?.leadingIcon?.name === "PLAY_ARROW_OUTLINED" || /views|visualizaciones/i.test(label)) viewsText = text || label;
					else if (/ago|hace|yesterday|ayer/i.test(text)) publishedText = text;
					else if (!channelTitle && text) channelTitle = text;
				}
				const views = parseViewCount(viewsText);
				if (videoId && typeof title === "string" && title && views > 0) videos.set(videoId, {
					videoId,
					title,
					channelTitle,
					views,
					publishedText,
					durationSeconds: 0
				});
			}
			for (const key of Object.keys(node)) visit(node[key], depth + 1);
		};
		visit(data.contents);
		const result = [...videos.values()].slice(0, 10);
		return result.length > 0 ? result : null;
	}
	// src/core/settings.ts
	var DEFAULT_SETTINGS = {
		apiKey: "",
		showFloatingButton: true,
		keywordMode: "api"
	};
	async function getSettings() {
		try {
			const stored = await browser.storage.sync.get(DEFAULT_SETTINGS);
			return {
				apiKey: typeof stored.apiKey === "string" ? stored.apiKey : "",
				showFloatingButton: stored.showFloatingButton !== false,
				keywordMode: stored.keywordMode === "session" ? "session" : "api"
			};
		} catch {
			return { ...DEFAULT_SETTINGS };
		}
	}
	// src/core/thumbnail.ts
	var THUMBNAIL_HOST = "https://i.ytimg.com/vi";
	var QUALITY_FALLBACKS = [
		"maxresdefault",
		"sddefault",
		"hqdefault"
	];
	async function drawToPixels(blob) {
		let bitmap;
		try {
			bitmap = await createImageBitmap(blob);
		} catch {
			return null;
		}
		const width = Math.min(480, bitmap.width);
		const height = Math.max(1, Math.round(bitmap.height / bitmap.width * width));
		const canvas = document.createElement("canvas");
		canvas.width = width;
		canvas.height = height;
		const context = canvas.getContext("2d", { willReadFrequently: true });
		if (!context) {
			bitmap.close();
			return null;
		}
		context.drawImage(bitmap, 0, 0, width, height);
		bitmap.close();
		try {
			return {
				data: context.getImageData(0, 0, width, height).data,
				width,
				height
			};
		} catch {
			return null;
		}
	}
	/**
	* Fetches the highest quality thumbnail available and converts it to raw
	* pixels. Runs in the sidebar (an extension page), where host permissions
	* allow reading i.ytimg.com without CORS issues.
	*/
	async function loadThumbnail(videoId, fallbackUrl) {
		const urls = [];
		if (videoId) for (const quality of QUALITY_FALLBACKS) urls.push(`${THUMBNAIL_HOST}/${videoId}/${quality}.jpg`);
		if (fallbackUrl) urls.push(fallbackUrl);
		for (const url of urls) {
			const controller = new AbortController();
			const timer = setTimeout(() => controller.abort(), 8e3);
			try {
				const response = await fetch(url, {
					credentials: "include",
					cache: "force-cache",
					signal: controller.signal
				});
				if (!response.ok) continue;
				const pixels = await drawToPixels(await response.blob());
				if (pixels) return pixels;
			} catch {} finally {
				clearTimeout(timer);
			}
		}
		return null;
	}
	// src/core/watch-page.ts
	/**
	* Extracts the public metadata of a video from a watch page HTML document.
	* YouTube embeds `ytInitialPlayerResponse` in a script tag, so no browser DOM
	* is required and the same parser can run in the background.
	*/
	function extractPublishedVideo(html) {
		if (!html || !html.includes("ytInitialPlayerResponse")) return null;
		const parsed = extractJsonObject(html, "ytInitialPlayerResponse");
		if (!parsed || typeof parsed !== "object") return null;
		const details = parsed.videoDetails;
		if (!details || typeof details !== "object") return null;
		const videoId = typeof details.videoId === "string" ? details.videoId : "";
		if (!videoId) return null;
		const tags = Array.isArray(details.keywords) ? details.keywords.filter((keyword) => typeof keyword === "string").map((keyword) => keyword.trim()).filter(Boolean) : [];
		return {
			videoId,
			title: typeof details.title === "string" ? details.title : "",
			tags
		};
	}
	// src/core/youtube-api.ts
	var API_BASE = "https://www.googleapis.com/youtube/v3";
	var YouTubeApiError = class extends Error {
		status;
		reason;
		constructor(status, reason) {
			super(reason);
			this.status = status;
			this.reason = reason;
			this.name = "YouTubeApiError";
		}
	};
	async function getJson(path, params, key) {
		const url = new URL(`${API_BASE}/${path}`);
		for (const [name, value] of Object.entries(params)) if (value) url.searchParams.set(name, value);
		url.searchParams.set("key", key);
		const response = await fetch(url.toString());
		if (!response.ok) {
			let reason = `http-${response.status}`;
			try {
				const body = await response.json();
				reason = body.error?.errors?.[0]?.reason ?? body.error?.status ?? reason;
			} catch {}
			throw new YouTubeApiError(response.status, reason);
		}
		return await response.json();
	}
	function parseIsoDuration(value) {
		const match = /^P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/.exec(value);
		if (!match) return 0;
		const days = Number(match[1] ?? 0);
		const hours = Number(match[2] ?? 0);
		const minutes = Number(match[3] ?? 0);
		const seconds = Number(match[4] ?? 0);
		return days * 86400 + hours * 3600 + minutes * 60 + seconds;
	}
	async function searchVideoIds(keyword, options, key) {
		const params = {
			part: "snippet",
			type: "video",
			maxResults: "10",
			q: keyword
		};
		if (options.regionCode) params.regionCode = options.regionCode;
		if (options.relevanceLanguage) params.relevanceLanguage = options.relevanceLanguage;
		const data = await getJson("search", params, key);
		const ids = [];
		const seen = /* @__PURE__ */ new Set();
		for (const item of data.items ?? []) {
			const id = item.id?.videoId;
			if (!id || seen.has(id)) continue;
			seen.add(id);
			ids.push(id);
		}
		return ids.slice(0, 10);
	}
	async function fetchVideoItems(ids, key) {
		if (ids.length === 0) return [];
		const data = await getJson("videos", {
			part: "snippet,statistics,contentDetails",
			id: ids.join(","),
			maxResults: "50"
		}, key);
		const parsed = [];
		for (const item of data.items ?? []) {
			const videoId = typeof item.id === "string" ? item.id : "";
			if (!videoId) continue;
			parsed.push({
				videoId,
				title: item.snippet?.title ?? "",
				channelId: item.snippet?.channelId ?? "",
				channelTitle: item.snippet?.channelTitle ?? "",
				views: Number(item.statistics?.viewCount ?? 0) || 0,
				publishedAt: item.snippet?.publishedAt ?? "",
				durationSeconds: parseIsoDuration(item.contentDetails?.duration ?? "")
			});
		}
		const byId = new Map(parsed.map((video) => [video.videoId, video]));
		return ids.map((id) => byId.get(id)).filter((video) => Boolean(video));
	}
	async function fetchChannelStats(ids, key) {
		if (ids.length === 0) return /* @__PURE__ */ new Map();
		const data = await getJson("channels", {
			part: "statistics",
			id: ids.join(",")
		}, key);
		const stats = /* @__PURE__ */ new Map();
		for (const item of data.items ?? []) {
			const id = typeof item.id === "string" ? item.id : "";
			if (!id) continue;
			const hidden = item.statistics?.hiddenSubscriberCount === true;
			stats.set(id, hidden ? 0 : Number(item.statistics?.subscriberCount ?? 0) || 0);
		}
		return stats;
	}
	// src/background/index.ts
	var WATCH_PREFIX = "https://www.youtube.com/watch";
	var STUDIO_PREFIX = "https://studio.youtube.com/";
	var PUBLISHED_TAGS_TTL = 6e5;
	var TAG_FETCH_TIMEOUT = 5e3;
	var CHANNEL_TTL = 9e5;
	var CHANNEL_TIMEOUT = 1e4;
	var THUMB_METRICS_TTL = 6e5;
	var KEYWORD_CACHE_KEY = "keyword-cache";
	var KEYWORD_TTL = 864e5;
	var SESSION_TTL = 432e5;
	var SESSION_TIMEOUT = 1e4;
	var SESSION_MIN_INTERVAL = 2e3;
	var lastSessionSearchAt = 0;
	var publishedTagsCache = /* @__PURE__ */ new Map();
	var channelOutliersCache = /* @__PURE__ */ new Map();
	var thumbnailMetricsCache = /* @__PURE__ */ new Map();
	/**
	* Runs in the page's MAIN world so it can read `ytInitialPlayerResponse`.
	* It must stay self-contained: Firefox serialises this function and evaluates
	* it in the page, so it cannot close over anything from this module.
	*/
	function readPlayerResponseInPage() {
		const page = window;
		let response = null;
		try {
			const player = document.getElementById("movie_player");
			if (player && typeof player.getPlayerResponse === "function") response = player.getPlayerResponse();
		} catch {
			response = null;
		}
		if (!response) response = page.ytInitialPlayerResponse;
		const details = response && response.videoDetails;
		if (!details) return null;
		const microformat = response.microformat && response.microformat.playerMicroformatRenderer;
		const thumbnails = details.thumbnail && Array.isArray(details.thumbnail.thumbnails) ? details.thumbnail.thumbnails : [];
		return {
			videoId: String(details.videoId ?? ""),
			title: String(details.title ?? ""),
			keywords: Array.isArray(details.keywords) ? details.keywords.map((keyword) => String(keyword)) : [],
			viewCount: details.viewCount != null ? Number(details.viewCount) : null,
			lengthSeconds: details.lengthSeconds != null ? Number(details.lengthSeconds) : null,
			channel: String(details.author ?? ""),
			description: String(details.shortDescription ?? ""),
			thumbnails: thumbnails.map((thumb) => String((thumb && thumb.url) ?? "")).filter((url) => url.length > 0),
			publishedAt: microformat && microformat.publishDate ? String(microformat.publishDate) : microformat && microformat.uploadDate ? String(microformat.uploadDate) : null,
			category: microformat && microformat.category ? String(microformat.category) : null
		};
	}
	async function readFromMainWorld(tabId) {
		try {
			return normalizeRawVideo((await browser.scripting.executeScript({
				target: { tabId },
				func: readPlayerResponseInPage,
				world: "MAIN"
			}))?.[0]?.result);
		} catch {
			return null;
		}
	}
	function wait(ms) {
		return new Promise((resolve) => setTimeout(resolve, ms));
	}
	async function collectFromWatch(tabId, expectedId) {
		let raw = await readFromMainWorld(tabId);
		if (!raw || raw.videoId && raw.videoId !== expectedId) {
			await wait(350);
			raw = await readFromMainWorld(tabId);
		}
		if (raw && raw.videoId && raw.videoId !== expectedId) raw = null;
		if (!raw) try {
			const candidate = normalizeRawVideo(await browser.tabs.sendMessage(tabId, { type: "READ_PLAYER_RESPONSE" }));
			if (candidate && candidate.videoId === expectedId) raw = candidate;
		} catch {
			raw = null;
		}
		if (!raw || !raw.title) return null;
		return toVideoData(raw, "watch");
	}
	async function collectFromStudio(tabId) {
		let data = null;
		try {
			data = await browser.tabs.sendMessage(tabId, { type: "GET_STUDIO_DATA" });
		} catch {
			return null;
		}
		if (!data) return null;
		let result = data;
		if (result.visibility !== "scheduled" && result.visibility !== "private" && result.tags.length === 0 && result.videoId) {
			const tags = await fetchPublishedTags(result.videoId);
			if (tags.length > 0) result = {
				...result,
				tags
			};
		}
		if (!result.thumbnailMetrics) {
			const urls = [result.thumbnailUrl, result.thumbnailFallbackUrl].filter((url) => typeof url === "string" && url.length > 0);
			for (const url of urls) {
				const cached = thumbnailMetricsCache.get(url);
				if (cached && Date.now() - cached.at < THUMB_METRICS_TTL) {
					result = {
						...result,
						thumbnailMetrics: cached.metrics
					};
					break;
				}
				const pixels = await loadThumbnail(null, url);
				if (!pixels) continue;
				const metrics = computeThumbMetrics(pixels);
				thumbnailMetricsCache.set(url, {
					metrics,
					at: Date.now()
				});
				if (thumbnailMetricsCache.size > 50) {
					const oldest = thumbnailMetricsCache.keys().next().value;
					if (oldest) thumbnailMetricsCache.delete(oldest);
				}
				result = {
					...result,
					thumbnailMetrics: metrics
				};
				break;
			}
		}
		return result;
	}
	async function fetchPublishedTags(videoId) {
		const cached = publishedTagsCache.get(videoId);
		if (cached && Date.now() - cached.fetchedAt < PUBLISHED_TAGS_TTL) return cached.tags;
		const controller = new AbortController();
		const timer = setTimeout(() => controller.abort(), TAG_FETCH_TIMEOUT);
		try {
			const response = await fetch(`https://www.youtube.com/watch?v=${encodeURIComponent(videoId)}`, {
				credentials: "include",
				cache: "no-store",
				signal: controller.signal
			});
			if (!response.ok) return [];
			const published = extractPublishedVideo(await response.text());
			const tags = published && published.videoId === videoId ? published.tags : [];
			publishedTagsCache.set(videoId, {
				tags,
				fetchedAt: Date.now()
			});
			if (publishedTagsCache.size > 50) {
				const oldest = publishedTagsCache.keys().next().value;
				if (oldest) publishedTagsCache.delete(oldest);
			}
			return tags;
		} catch {
			return [];
		} finally {
			clearTimeout(timer);
		}
	}
	function isChannelUrl(url) {
		try {
			const parsed = new URL(url);
			if (parsed.hostname !== "www.youtube.com") return false;
			return /^\/(@[^/]+|channel\/UC[\w-]{22}|c\/[^/]+|user\/[^/]+)(\/|$)/.test(parsed.pathname);
		} catch {
			return false;
		}
	}
	function normalizeChannelPath(path) {
		return path.replace(/\/+$/, "").replace(/\/(videos|shorts|streams|playlists|community|about|featured)$/i, "") || "/";
	}
	async function fetchChannelPage(path) {
		const base = normalizeChannelPath(path);
		const controller = new AbortController();
		const timer = setTimeout(() => controller.abort(), CHANNEL_TIMEOUT);
		try {
			const response = await fetch(`https://www.youtube.com${base}/videos?hl=en`, {
				credentials: "include",
				cache: "no-store",
				signal: controller.signal
			});
			if (!response.ok) return null;
			return parseChannelPage(await response.text());
		} catch {
			return null;
		} finally {
			clearTimeout(timer);
		}
	}
	async function getChannelOutliers(tabId) {
		if (typeof tabId !== "number") return {
			ok: false,
			error: "no-tab"
		};
		let tab;
		try {
			tab = await browser.tabs.get(tabId);
		} catch {
			return {
				ok: false,
				error: "no-tab"
			};
		}
		const url = tab.url ?? "";
		if (!isChannelUrl(url)) return {
			ok: true,
			data: null
		};
		const path = new URL(url).pathname;
		const cacheKey = normalizeChannelPath(path);
		const cached = channelOutliersCache.get(cacheKey);
		if (cached && Date.now() - cached.fetchedAt < CHANNEL_TTL) return {
			ok: true,
			data: {
				...cached.data,
				cached: true
			}
		};
		const page = await fetchChannelPage(path);
		if (!page) return {
			ok: false,
			error: "channel"
		};
		const { medianViews, videos } = computeOutliers(page.videos);
		const data = {
			channelId: page.channelId,
			channelName: page.channelName || cacheKey,
			medianViews,
			sampleSize: page.videos.length,
			videos,
			cached: false
		};
		channelOutliersCache.set(cacheKey, {
			data,
			fetchedAt: Date.now()
		});
		if (channelOutliersCache.size > 30) {
			const oldest = channelOutliersCache.keys().next().value;
			if (oldest) channelOutliersCache.delete(oldest);
		}
		return {
			ok: true,
			data
		};
	}
	async function readKeywordCache() {
		try {
			const value = (await browser.storage.local.get(KEYWORD_CACHE_KEY))[KEYWORD_CACHE_KEY];
			return value && typeof value === "object" ? value : {};
		} catch {
			return {};
		}
	}
	async function writeKeywordCache(cache) {
		const entries = Object.entries(cache).filter(([, entry]) => Date.now() - entry.at < KEYWORD_TTL).sort((a, b) => a[1].at - b[1].at).slice(-40);
		try {
			await browser.storage.local.set({ [KEYWORD_CACHE_KEY]: Object.fromEntries(entries) });
		} catch {}
	}
	async function searchApiKeyword(rawKeyword) {
		const keyword = typeof rawKeyword === "string" ? rawKeyword.trim().slice(0, 120) : "";
		if (!keyword) return {
			ok: false,
			error: "empty",
			code: "bad-request"
		};
		const apiKey = (await getSettings()).apiKey.trim();
		if (!apiKey) return {
			ok: false,
			error: "no-key",
			code: "no-key"
		};
		const [language, region] = (browser.i18n.getUILanguage() || "en-US").split("-");
		const regionCode = region && /^[a-z]{2}$/i.test(region) ? region.toUpperCase() : void 0;
		const cacheKey = `${keyword.toLocaleLowerCase()}|${regionCode ?? ""}|${language ?? ""}`;
		const quota = await getQuota();
		const cache = await readKeywordCache();
		const hit = cache[cacheKey];
		if (hit && hit.result && Array.isArray(hit.result.top) && Date.now() - hit.at < KEYWORD_TTL) return {
			ok: true,
			data: {
				...hit.result,
				cached: true,
				quota
			}
		};
		if (!canSearch(quota)) return {
			ok: false,
			error: "quota",
			code: "quota"
		};
		try {
			const ids = await searchVideoIds(keyword, {
				regionCode,
				relevanceLanguage: language
			}, apiKey);
			await addSearch();
			if (ids.length === 0) {
				const empty = {
					...computeKeywordResult(keyword, []),
					cached: false,
					quota: await getQuota()
				};
				cache[cacheKey] = {
					result: empty,
					at: Date.now()
				};
				await writeKeywordCache(cache);
				return {
					ok: true,
					data: empty
				};
			}
			const videos = await fetchVideoItems(ids, apiKey);
			await addUnits(1);
			const channelIds = [...new Set(videos.map((video) => video.channelId).filter(Boolean))];
			const channels = await fetchChannelStats(channelIds, apiKey);
			if (channelIds.length > 0) await addUnits(1);
			const result = {
				...computeKeywordResult(keyword, videos.map((video) => ({
					videoId: video.videoId,
					title: video.title,
					channelId: video.channelId,
					channelTitle: video.channelTitle,
					views: video.views,
					subs: channels.get(video.channelId) ?? 0,
					publishedAt: video.publishedAt,
					durationSeconds: video.durationSeconds
				}))),
				cached: false,
				quota: await getQuota()
			};
			cache[cacheKey] = {
				result,
				at: Date.now()
			};
			await writeKeywordCache(cache);
			return {
				ok: true,
				data: result
			};
		} catch (error) {
			if (error instanceof YouTubeApiError) {
				if (error.status === 403 && /quota/i.test(error.reason)) return {
					ok: false,
					error: error.reason,
					code: "quota"
				};
				if (error.status === 400 || error.status === 403) return {
					ok: false,
					error: error.reason,
					code: "invalid-key"
				};
				return {
					ok: false,
					error: error.reason,
					code: "api"
				};
			}
			return {
				ok: false,
				error: String(error),
				code: "api"
			};
		}
	}
	async function searchSessionKeyword(rawKeyword) {
		const keyword = typeof rawKeyword === "string" ? rawKeyword.trim().slice(0, 120) : "";
		if (!keyword) return {
			ok: false,
			error: "empty",
			code: "bad-request"
		};
		const quota = await getQuota();
		const language = (browser.i18n.getUILanguage() || "en").split("-")[0] || "en";
		const cacheKey = `session|${keyword.toLocaleLowerCase()}|${language}`;
		const cache = await readKeywordCache();
		const hit = cache[cacheKey];
		if (hit && hit.result && Array.isArray(hit.result.top) && Date.now() - hit.at < SESSION_TTL) return {
			ok: true,
			data: {
				...hit.result,
				cached: true,
				quota
			}
		};
		const since = Date.now() - lastSessionSearchAt;
		if (since < SESSION_MIN_INTERVAL) await wait(SESSION_MIN_INTERVAL - since);
		lastSessionSearchAt = Date.now();
		const controller = new AbortController();
		const timer = setTimeout(() => controller.abort(), SESSION_TIMEOUT);
		try {
			const response = await fetch(`https://www.youtube.com/results?search_query=${encodeURIComponent(keyword)}&hl=en`, {
				credentials: "include",
				cache: "no-store",
				signal: controller.signal
			});
			if (!response.ok) return {
				ok: false,
				error: `http-${response.status}`,
				code: "session"
			};
			const videos = parseSearchPage(await response.text());
			if (!videos || videos.length === 0) return {
				ok: false,
				error: "empty",
				code: "session"
			};
			const now = Date.now();
			const result = {
				...computeKeywordResult(keyword, videos.map((video) => {
					const days = parseRelativeAgeDays(video.publishedText);
					return {
						videoId: video.videoId,
						title: video.title,
						channelId: "",
						channelTitle: video.channelTitle,
						views: video.views,
						subs: 0,
						publishedAt: typeof days === "number" ? (/* @__PURE__ */ new Date(now - days * 864e5)).toISOString() : "",
						publishedText: video.publishedText,
						publishedDaysAgo: days,
						durationSeconds: video.durationSeconds
					};
				}), {
					mode: "session",
					subsAvailable: false
				}),
				cached: false,
				quota
			};
			cache[cacheKey] = {
				result,
				at: Date.now()
			};
			await writeKeywordCache(cache);
			return {
				ok: true,
				data: result
			};
		} catch {
			return {
				ok: false,
				error: "session",
				code: "session"
			};
		} finally {
			clearTimeout(timer);
		}
	}
	async function getStudioTabId() {
		try {
			const tab = (await browser.tabs.query({
				active: true,
				currentWindow: true
			}))[0];
			if (tab?.id && (tab.url ?? "").startsWith(STUDIO_PREFIX)) return tab.id;
		} catch {}
		return null;
	}
	async function writeStudio(message) {
		const tabId = await getStudioTabId();
		if (typeof tabId !== "number") return {
			ok: false,
			error: "no-studio"
		};
		try {
			return await browser.tabs.sendMessage(tabId, message);
		} catch (error) {
			return {
				ok: false,
				error: String(error)
			};
		}
	}
	async function expandStudioTags(tabId) {
		let id = tabId;
		if (typeof id !== "number") id = await getStudioTabId() ?? void 0;
		if (typeof id !== "number") return {
			ok: false,
			error: "no-tab"
		};
		try {
			await browser.tabs.sendMessage(id, { type: "EXPAND_STUDIO_TAGS" });
			return { ok: true };
		} catch (error) {
			return {
				ok: false,
				error: String(error)
			};
		}
	}
	async function quotaResponse() {
		try {
			return {
				ok: true,
				data: await getQuota()
			};
		} catch {
			return { ok: false };
		}
	}
	async function getVideoData(tabId) {
		if (typeof tabId !== "number") return {
			ok: false,
			error: "no-tab"
		};
		let tab;
		try {
			tab = await browser.tabs.get(tabId);
		} catch {
			return {
				ok: false,
				error: "no-tab"
			};
		}
		const url = tab.url ?? "";
		try {
			if (url.startsWith(WATCH_PREFIX)) {
				const videoId = new URL(url).searchParams.get("v");
				if (!videoId) return {
					ok: true,
					data: null
				};
				return {
					ok: true,
					data: await collectFromWatch(tabId, videoId)
				};
			}
			if (url.startsWith(STUDIO_PREFIX)) return {
				ok: true,
				data: await collectFromStudio(tabId)
			};
		} catch (error) {
			return {
				ok: false,
				error: String(error)
			};
		}
		return {
			ok: true,
			data: null
		};
	}
	async function openSidebar() {
		try {
			await browser.sidebarAction.open();
			return { ok: true };
		} catch (error) {
			return {
				ok: false,
				error: String(error)
			};
		}
	}
	browser.runtime.onMessage.addListener(((message, sender) => {
		if (!message || typeof message !== "object") return void 0;
		const request = message;
		switch (request.type) {
			case "GET_VIDEO_DATA": return getVideoData(typeof request.tabId === "number" ? request.tabId : sender.tab?.id);
			case "GET_CHANNEL_OUTLIERS": return getChannelOutliers(typeof request.tabId === "number" ? request.tabId : sender.tab?.id);
			case "SEARCH_KEYWORD": {
				const keyword = typeof request.keyword === "string" ? request.keyword : "";
				return request.mode === "session" ? searchSessionKeyword(keyword) : searchApiKeyword(keyword);
			}
			case "EXPAND_STUDIO_TAGS": return expandStudioTags(sender.tab?.id);
			case "ADD_STUDIO_TAGS": {
				const tags = Array.isArray(request.tags) ? request.tags.filter((tag) => typeof tag === "string") : [];
				if (tags.length === 0) return {
					ok: false,
					error: "empty"
				};
				return writeStudio({
					type: "ADD_STUDIO_TAGS",
					tags,
					videoId: typeof request.videoId === "string" ? request.videoId : null
				});
			}
			case "SET_STUDIO_TITLE": {
				const title = typeof request.title === "string" ? request.title.trim().slice(0, 100) : "";
				if (!title) return {
					ok: false,
					error: "empty"
				};
				return writeStudio({
					type: "SET_STUDIO_TITLE",
					title,
					videoId: typeof request.videoId === "string" ? request.videoId : null
				});
			}
			case "GET_QUOTA": return quotaResponse();
			case "OPEN_SIDEBAR": return openSidebar();
			default: return;
		}
	}));
	browser.action.onClicked.addListener(() => {
		browser.sidebarAction.toggle();
	});
})();
