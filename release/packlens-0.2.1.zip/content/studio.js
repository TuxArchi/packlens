(function() {
	// src/core/image-metrics.ts
	var MOBILE_WIDTH = 168;
	var EDGE_MAGNITUDE = 160;
	function percentile(sorted, ratio) {
		if (sorted.length === 0) return 0;
		return sorted[Math.min(sorted.length - 1, Math.max(0, Math.round((sorted.length - 1) * ratio)))];
	}
	function downscale(lum, width, height, targetWidth) {
		const scale = Math.min(1, targetWidth / width);
		const outWidth = Math.max(1, Math.round(width * scale));
		const outHeight = Math.max(1, Math.round(height * scale));
		const out = new Float32Array(outWidth * outHeight);
		const xRatio = width / outWidth;
		const yRatio = height / outHeight;
		for (let y = 0; y < outHeight; y += 1) {
			const y0 = Math.floor(y * yRatio);
			const y1 = Math.min(height, Math.max(y0 + 1, Math.floor((y + 1) * yRatio)));
			for (let x = 0; x < outWidth; x += 1) {
				const x0 = Math.floor(x * xRatio);
				const x1 = Math.min(width, Math.max(x0 + 1, Math.floor((x + 1) * xRatio)));
				let sum = 0;
				let count = 0;
				for (let yy = y0; yy < y1; yy += 1) for (let xx = x0; xx < x1; xx += 1) {
					sum += lum[yy * width + xx];
					count += 1;
				}
				out[y * outWidth + x] = count > 0 ? sum / count : 0;
			}
		}
		return {
			lum: out,
			width: outWidth,
			height: outHeight
		};
	}
	function laplacianVariance(lum, width, height) {
		let sum = 0;
		let squareSum = 0;
		let count = 0;
		for (let y = 1; y < height - 1; y += 1) for (let x = 1; x < width - 1; x += 1) {
			const i = y * width + x;
			const value = 4 * lum[i] - lum[i - 1] - lum[i + 1] - lum[i - width] - lum[i + width];
			sum += value;
			squareSum += value * value;
			count += 1;
		}
		if (count === 0) return 0;
		const mean = sum / count;
		return Math.max(0, squareSum / count - mean * mean);
	}
	function computeThumbMetrics(image) {
		const { data, width, height } = image;
		const pixelCount = width * height;
		if (pixelCount === 0) return {
			width,
			height,
			luminanceMean: 0,
			luminanceStd: 0,
			tonalRange: 0,
			edgeDensity: 0,
			colorfulness: 0,
			saturationMean: 0,
			mobileRange: 0,
			mobileRetention: 0,
			mobileSharpness: 0
		};
		const lum = new Float32Array(pixelCount);
		let luminanceSum = 0;
		let saturationSum = 0;
		let rgSum = 0;
		let rgSquareSum = 0;
		let ybSum = 0;
		let ybSquareSum = 0;
		for (let i = 0, p = 0; i < pixelCount; i += 1, p += 4) {
			const r = data[p];
			const g = data[p + 1];
			const b = data[p + 2];
			const l = .2126 * r + .7152 * g + .0722 * b;
			lum[i] = l;
			luminanceSum += l;
			const max = Math.max(r, g, b);
			saturationSum += max === 0 ? 0 : (max - Math.min(r, g, b)) / max;
			const rg = r - g;
			const yb = .5 * (r + g) - b;
			rgSum += rg;
			rgSquareSum += rg * rg;
			ybSum += yb;
			ybSquareSum += yb * yb;
		}
		const luminanceMean = luminanceSum / pixelCount;
		let varianceSum = 0;
		for (let i = 0; i < pixelCount; i += 1) {
			const delta = lum[i] - luminanceMean;
			varianceSum += delta * delta;
		}
		const luminanceStd = Math.sqrt(varianceSum / pixelCount);
		const sorted = Float32Array.from(lum).sort();
		const tonalRange = Math.max(0, percentile(sorted, .95) - percentile(sorted, .05));
		const rgMean = rgSum / pixelCount;
		const ybMean = ybSum / pixelCount;
		const rgVariance = Math.max(0, rgSquareSum / pixelCount - rgMean * rgMean);
		const ybVariance = Math.max(0, ybSquareSum / pixelCount - ybMean * ybMean);
		const colorfulness = Math.sqrt(rgVariance + ybVariance) + .3 * Math.sqrt(rgMean * rgMean + ybMean * ybMean);
		let edgePixels = 0;
		let edgeSamples = 0;
		for (let y = 1; y < height - 1; y += 1) for (let x = 1; x < width - 1; x += 1) {
			const i = y * width + x;
			const gx = lum[i - width + 1] + 2 * lum[i + 1] + lum[i + width + 1] - (lum[i - width - 1] + 2 * lum[i - 1] + lum[i + width - 1]);
			const gy = lum[i + width - 1] + 2 * lum[i + width] + lum[i + width + 1] - (lum[i - width - 1] + 2 * lum[i - width] + lum[i - width + 1]);
			if (Math.abs(gx) + Math.abs(gy) > EDGE_MAGNITUDE) edgePixels += 1;
			edgeSamples += 1;
		}
		const edgeDensity = edgeSamples > 0 ? edgePixels / edgeSamples : 0;
		const mobile = downscale(lum, width, height, MOBILE_WIDTH);
		const mobileSorted = Float32Array.from(mobile.lum).sort();
		const mobileRange = Math.max(0, percentile(mobileSorted, .95) - percentile(mobileSorted, .05));
		const mobileRetention = tonalRange > 1 ? Math.min(1.5, mobileRange / tonalRange) : 0;
		return {
			width,
			height,
			luminanceMean,
			luminanceStd,
			tonalRange,
			edgeDensity,
			colorfulness,
			saturationMean: saturationSum / pixelCount,
			mobileRange,
			mobileRetention,
			mobileSharpness: laplacianVariance(mobile.lum, mobile.width, mobile.height)
		};
	}
	// src/core/i18n.ts
	function t(key, substitutions) {
		try {
			return browser.i18n.getMessage(key, substitutions) || key;
		} catch {
			return key;
		}
	}
	// src/core/tags.ts
	var UI_LABELS = /* @__PURE__ */ new Set([
		"add tag",
		"add tags",
		"add a tag",
		"añadir etiqueta",
		"añadir etiquetas",
		"agregar etiqueta",
		"agregar etiquetas",
		"tags",
		"etiquetas",
		"show more",
		"show less",
		"mostrar más",
		"mostrar mas",
		"mostrar menos",
		"close",
		"remove",
		"eliminar"
	]);
	function cleanTag(raw) {
		const value = raw.replace(/\u200b/g, "").replace(/\s+/g, " ").trim().replace(/^["']|["']$/g, "");
		if (!value) return null;
		if (value.length > 100) return null;
		if (UI_LABELS.has(value.toLocaleLowerCase())) return null;
		return value;
	}
	function cleanTags(values) {
		const cleaned = [];
		for (const value of values) {
			const tag = cleanTag(value);
			if (tag) cleaned.push(tag);
		}
		return normalizeTags(cleaned);
	}
	function parseTagsFromText(text) {
		return cleanTags(text.split(/[,\n;]+/));
	}
	function normalizeTags(tags) {
		const seen = /* @__PURE__ */ new Set();
		const result = [];
		for (const raw of tags) {
			const tag = raw.replace(/\s+/g, " ").trim();
			if (!tag) continue;
			const key = tag.toLocaleLowerCase();
			if (seen.has(key)) continue;
			seen.add(key);
			result.push(tag);
		}
		return result;
	}
	function tagCharacters(tags) {
		return tags.join(",").length;
	}
	/**
	* Returns the suggested tags that are not already present and still fit inside
	* the tag field budget. It never removes existing tags.
	*/
	function fitTags(existing, suggested, limit = 480) {
		const current = normalizeTags(existing);
		const seen = new Set(current.map((tag) => tag.toLocaleLowerCase()));
		const result = [];
		for (const raw of suggested) {
			const tag = raw.replace(/\s+/g, " ").trim();
			if (!tag) continue;
			const key = tag.toLocaleLowerCase();
			if (seen.has(key)) continue;
			if (tagCharacters([
				...current,
				...result,
				tag
			]) > limit) continue;
			seen.add(key);
			result.push(tag);
		}
		return result;
	}
	// src/content/studio.ts
	var EDIT_PAGE = /\/video\/([\w-]{11})\/edit/;
	function currentVideoId() {
		const match = location.pathname.match(EDIT_PAGE);
		return match ? match[1] : null;
	}
	function isEditPage() {
		return EDIT_PAGE.test(location.pathname);
	}
	/**
	* Queries the light DOM and, when nothing matches, the open shadow roots of
	* custom elements. YouTube Studio mixes Polymer (light DOM) and newer views
	* with Shadow DOM, so querying only `document` is not enough.
	*/
	function queryDeep(selector, root = document, depth = 0) {
		const direct = Array.from(root.querySelectorAll(selector));
		if (direct.length > 0 || depth >= 3) return direct;
		const found = [];
		for (const host of Array.from(root.querySelectorAll("*"))) {
			if (!host.tagName.includes("-")) continue;
			const shadow = host.shadowRoot;
			if (shadow) found.push(...queryDeep(selector, shadow, depth + 1));
		}
		return found;
	}
	function textOf(selector) {
		return (queryDeep(selector)[0]?.textContent ?? "").replace(/\u200b/g, "").trim();
	}
	function readChips(scope) {
		const labels = queryDeep("#chip-text, .chip-text", scope);
		return cleanTags((labels.length > 0 ? labels : queryDeep("ytcp-chip", scope)).map((chip) => chip.textContent ?? ""));
	}
	function readInputs(scope) {
		return cleanTags(queryDeep("input, textarea", scope).map((input) => input.value ?? "").filter((value) => value.trim().length > 0).flatMap((value) => parseTagsFromText(value)));
	}
	function looksLikeTagsInput(input) {
		const haystack = [
			input.id,
			input.getAttribute("aria-label") ?? "",
			input.getAttribute("placeholder") ?? "",
			input.getAttribute("name") ?? ""
		].join(" ").toLocaleLowerCase();
		return /tag|etiqueta/.test(haystack);
	}
	function collectTags() {
		const container = queryDeep("#tags-container")[0];
		if (container) {
			const fromChips = readChips(container);
			if (fromChips.length > 0) return fromChips;
			const fromInputs = readInputs(container);
			if (fromInputs.length > 0) return fromInputs;
		}
		const editor = queryDeep("ytcp-video-metadata-editor, ytcp-video-metadata-editor-basics")[0];
		const bars = editor ? queryDeep("ytcp-chip-bar", editor) : queryDeep("ytcp-chip-bar");
		for (const bar of bars) {
			const tags = readChips(bar);
			if (tags.length > 0) return tags;
		}
		const tagInputs = queryDeep("input, textarea", editor ?? document).filter(looksLikeTagsInput);
		if (tagInputs.length > 0) return cleanTags(tagInputs.flatMap((input) => parseTagsFromText(input.value ?? "")));
		return [];
	}
	function detectVisibility() {
		let text = [...queryDeep("ytcp-video-metadata-visibility"), ...queryDeep("[id*=\"visibility\"]")].map((scope) => scope.textContent ?? "").join(" ").toLocaleLowerCase();
		if (!text) text = document.body.innerText.slice(0, 2e4).toLocaleLowerCase();
		if (/programado|scheduled/.test(text)) return "scheduled";
		if (/privado|private/.test(text)) return "private";
		if (/oculto|unlisted/.test(text)) return "unlisted";
		if (/público|public/.test(text)) return "public";
		return "unknown";
	}
	var thumbnailMetricsCache = /* @__PURE__ */ new Map();
	/**
	* The editor thumbnail lives on i9.ytimg.com with a signed, short-lived URL.
	* Loading it again with CORS from the page context keeps the canvas clean and
	* works for scheduled videos, where i.ytimg.com does not have the image yet.
	*/
	async function analyzeEditorThumbnail(image) {
		const src = image?.src;
		if (!src) return null;
		const cached = thumbnailMetricsCache.get(src);
		if (cached) return cached;
		const probe = new Image();
		if (/^https?:/i.test(src)) probe.crossOrigin = "anonymous";
		if (!await new Promise((resolve) => {
			const timer = window.setTimeout(() => resolve(false), 4e3);
			probe.onload = () => {
				window.clearTimeout(timer);
				resolve(true);
			};
			probe.onerror = () => {
				window.clearTimeout(timer);
				resolve(false);
			};
			probe.src = src;
		}) || probe.naturalWidth === 0) return null;
		try {
			const width = 480;
			const height = Math.max(1, Math.round(probe.naturalHeight / probe.naturalWidth * width));
			const canvas = document.createElement("canvas");
			canvas.width = width;
			canvas.height = height;
			const context = canvas.getContext("2d", { willReadFrequently: true });
			if (!context) return null;
			context.drawImage(probe, 0, 0, width, height);
			const metrics = computeThumbMetrics({
				data: context.getImageData(0, 0, width, height).data,
				width,
				height
			});
			thumbnailMetricsCache.set(src, metrics);
			if (thumbnailMetricsCache.size > 20) {
				const oldest = thumbnailMetricsCache.keys().next().value;
				if (oldest) thumbnailMetricsCache.delete(oldest);
			}
			return metrics;
		} catch {
			return null;
		}
	}
	async function collect() {
		const videoId = currentVideoId();
		const title = textOf("#title-textarea #textbox") || textOf("ytcp-social-suggestions-textbox#title-textarea #textbox");
		const description = textOf("#description-textarea #textbox") || textOf("ytcp-social-suggestions-textbox#description-textarea #textbox");
		if (!title && !videoId) return null;
		const editorThumbnail = queryDeep("ytcp-thumbnail-editor img, #thumbnail img")[0];
		return {
			source: "studio",
			videoId,
			title,
			thumbnailUrl: editorThumbnail?.src ? editorThumbnail.src : videoId ? `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg` : null,
			thumbnailFallbackUrl: videoId ? `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg` : null,
			thumbnailMetrics: await analyzeEditorThumbnail(editorThumbnail),
			visibility: detectVisibility(),
			channel: null,
			views: null,
			publishedAt: null,
			lengthSeconds: null,
			tags: collectTags(),
			description,
			category: null
		};
	}
	/**
	* A stable signature of the fields we care about. Mutations that do not change
	* title or tags (autosave spinners, counters, previews...) are ignored.
	*/
	function signature() {
		if (!isEditPage()) return "";
		const title = textOf("#title-textarea #textbox") || textOf("ytcp-social-suggestions-textbox#title-textarea #textbox");
		const description = textOf("#description-textarea #textbox") || textOf("ytcp-social-suggestions-textbox#description-textarea #textbox");
		const thumbnail = queryDeep("ytcp-thumbnail-editor img, #thumbnail img")[0];
		return `${currentVideoId() ?? ""}\u0000${title}\u0000${collectTags().join("")}\u0000${hash(description)}\u0000${thumbnail?.src ?? ""}`;
	}
	async function expandEditor() {
		if (queryDeep("#tags-container").length > 0) return true;
		const editor = queryDeep("ytcp-video-metadata-editor, ytcp-video-metadata-editor-basics")[0] ?? document.body;
		const scopes = editor === document.body ? [document] : [editor, document];
		for (const scope of scopes) {
			const control = queryDeep("button, ytcp-button, tp-yt-paper-button, [role=\"button\"]", scope).find((element) => {
				const text = (element.textContent ?? "").replace(/\s+/g, " ").trim();
				if (!/^(mostrar más|show more|más opciones|more options)$/i.test(text)) return false;
				return !element.closest("#description, #description-textarea, ytcp-social-suggestions-textbox");
			});
			if (!control) continue;
			control.click();
			await new Promise((resolve) => window.setTimeout(resolve, 700));
			if (queryDeep("#tags-container").length === 0) await new Promise((resolve) => window.setTimeout(resolve, 500));
			return true;
		}
		return false;
	}
	function wait(ms) {
		return new Promise((resolve) => window.setTimeout(resolve, ms));
	}
	function setNativeValue(input, value) {
		const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
		if (setter) setter.call(input, value);
		else input.value = value;
	}
	function dispatchInput(input, data) {
		try {
			input.dispatchEvent(new InputEvent("input", {
				bubbles: true,
				inputType: "insertText",
				data
			}));
		} catch {
			input.dispatchEvent(new Event("input", { bubbles: true }));
		}
	}
	function enterKey() {
		return new KeyboardEvent("keydown", {
			bubbles: true,
			cancelable: true,
			key: "Enter",
			code: "Enter",
			keyCode: 13,
			which: 13
		});
	}
	async function insertTag(bar, tag) {
		let input = null;
		try {
			input = typeof bar.getInput === "function" ? bar.getInput() : bar.querySelector("#text-input");
		} catch {
			return false;
		}
		if (!input) return false;
		const chipCount = () => queryDeep("ytcp-chip", bar).length;
		const before = chipCount();
		input.focus();
		try {
			setNativeValue(input, tag);
			dispatchInput(input, tag);
			input.dispatchEvent(enterKey());
			input.dispatchEvent(new KeyboardEvent("keyup", {
				bubbles: true,
				key: "Enter",
				code: "Enter",
				keyCode: 13,
				which: 13
			}));
		} catch {}
		await wait(160);
		if (chipCount() > before) return true;
		try {
			bar.setInputText?.(tag);
			bar.handleInputKeyDown?.(enterKey());
		} catch {}
		await wait(180);
		if (chipCount() > before) return true;
		try {
			setNativeValue(input, tag);
			dispatchInput(input, tag);
			input.dispatchEvent(new KeyboardEvent("keydown", {
				bubbles: true,
				cancelable: true,
				key: ",",
				code: "Comma",
				keyCode: 188,
				which: 188
			}));
		} catch {}
		await wait(180);
		return chipCount() > before;
	}
	async function addStudioTags(tags, videoId) {
		if (videoId && currentVideoId() !== videoId) return {
			ok: false,
			error: "mismatch"
		};
		if (!Array.isArray(tags) || tags.length === 0) return {
			ok: false,
			error: "empty"
		};
		let bar = queryDeep("#tags-container ytcp-chip-bar, ytcp-chip-bar")[0];
		if (!bar) {
			await expandEditor();
			bar = queryDeep("#tags-container ytcp-chip-bar, ytcp-chip-bar")[0];
		}
		if (!bar) return {
			ok: false,
			needsPaste: true,
			error: "no-input"
		};
		const toAdd = fitTags(collectTags(), tags);
		let added = 0;
		for (const tag of toAdd) if (await insertTag(bar, tag)) added += 1;
		else break;
		scheduleChange(true);
		if (added === 0 && toAdd.length > 0) return {
			ok: false,
			needsPaste: true,
			error: "write",
			added: 0,
			skipped: tags.length
		};
		return {
			ok: true,
			added,
			skipped: Math.max(0, tags.length - added)
		};
	}
	async function setStudioTitle(rawTitle, videoId) {
		if (videoId && currentVideoId() !== videoId) return {
			ok: false,
			error: "mismatch"
		};
		const title = typeof rawTitle === "string" ? rawTitle.trim().slice(0, 100) : "";
		if (!title) return {
			ok: false,
			error: "empty"
		};
		const field = queryDeep("#title-textarea #textbox")[0];
		if (!field) return {
			ok: false,
			needsPaste: true,
			error: "no-input"
		};
		field.focus();
		let applied = false;
		try {
			document.execCommand("selectAll", false);
			applied = document.execCommand("insertText", false, title);
		} catch {
			applied = false;
		}
		const current = (field.textContent ?? "").trim();
		if (!applied || current !== title) {
			if (field instanceof HTMLInputElement || field instanceof HTMLTextAreaElement) {
				const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(field), "value")?.set;
				if (setter) setter.call(field, title);
				else field.value = title;
			} else field.textContent = title;
			dispatchInput(field, title);
		}
		scheduleChange(true);
		return (field instanceof HTMLInputElement || field instanceof HTMLTextAreaElement ? field.value : field.textContent ?? "").trim() === title ? { ok: true } : {
			ok: false,
			needsPaste: true,
			error: "write"
		};
	}
	function hash(text) {
		let value = 0;
		for (let index = 0; index < text.length; index += 1) value = Math.imul(value, 31) + text.charCodeAt(index) | 0;
		return value;
	}
	var debounce;
	var burstStart = 0;
	var lastSignature = "";
	function scheduleChange(force = false) {
		if (!isEditPage()) return;
		const now = Date.now();
		if (burstStart === 0) burstStart = now;
		if (debounce) window.clearTimeout(debounce);
		const delay = now - burstStart > 2500 ? 0 : 650;
		debounce = window.setTimeout(() => {
			burstStart = 0;
			if (!isEditPage() || document.hidden) return;
			const next = signature();
			if (!force && next === lastSignature) return;
			lastSignature = next;
			browser.runtime.sendMessage({
				type: "VIDEO_CHANGED",
				videoId: currentVideoId()
			}).catch(() => void 0);
		}, delay);
	}
	document.addEventListener("input", (event) => {
		if (event.target?.closest?.("ytcp-video-metadata-editor, ytcp-video-metadata-editor-basics, ytcp-social-suggestions-textbox, ytcp-chip-bar, #tags-container")) scheduleChange();
	}, true);
	new MutationObserver(() => scheduleChange()).observe(document.documentElement, {
		childList: true,
		subtree: true,
		characterData: true
	});
	var lastHref = location.href;
	window.setInterval(() => {
		if (location.href !== lastHref) {
			lastHref = location.href;
			lastSignature = "";
			scheduleChange(true);
			return;
		}
		if (isEditPage() && !document.hidden) scheduleChange();
	}, 1500);
	browser.runtime.onMessage.addListener(((message) => {
		if (!message || typeof message !== "object") return void 0;
		const type = message.type;
		if (type === "GET_STUDIO_DATA") return Promise.resolve(collect());
		if (type === "EXPAND_STUDIO_TAGS") return expandEditor();
		if (type === "ADD_STUDIO_TAGS") {
			const data = message;
			return addStudioTags(Array.isArray(data.tags) ? data.tags.filter((tag) => typeof tag === "string") : [], typeof data.videoId === "string" ? data.videoId : null);
		}
		if (type === "SET_STUDIO_TITLE") {
			const data = message;
			return setStudioTitle(typeof data.title === "string" ? data.title : "", typeof data.videoId === "string" ? data.videoId : null);
		}
	}));
	var LAUNCHER_STYLES = `
:host { all: initial; }
.ytpl-studio-launcher {
  position: fixed;
  right: 18px;
  bottom: 18px;
  width: 46px;
  height: 46px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid #2a323d;
  border-radius: 50%;
  background: #0f1115;
  color: #22d3a6;
  font: 22px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  cursor: pointer;
  padding: 0;
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.45);
}

.ytpl-studio-launcher:hover {
  border-color: #22d3a6;
  transform: translateY(-1px);
}

.ytpl-studio-hint {
  position: fixed;
  right: 18px;
  bottom: 74px;
  max-width: 260px;
  padding: 8px 10px;
  border: 1px solid #2a323d;
  border-radius: 10px;
  background: #161a21;
  color: #e8edf4;
  font: 12px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.45);
}

.ytpl-studio-hint[hidden] {
  display: none;
}
`;
	function mountStudioLauncher() {
		if (document.getElementById("ytpl-studio-launcher")) return;
		const host = document.createElement("div");
		host.id = "ytpl-studio-launcher";
		host.style.cssText = "all:initial;position:fixed;right:0;bottom:0;width:0;height:0;z-index:2147483000;";
		const shadow = host.attachShadow({ mode: "open" });
		try {
			const sheet = new CSSStyleSheet();
			sheet.replaceSync(LAUNCHER_STYLES);
			shadow.adoptedStyleSheets = [sheet];
		} catch {
			const style = document.createElement("style");
			style.textContent = LAUNCHER_STYLES;
			shadow.appendChild(style);
		}
		const button = document.createElement("button");
		button.type = "button";
		button.className = "ytpl-studio-launcher";
		button.textContent = "◎";
		const label = `${t("studio.openPanel")} · Alt+Shift+P`;
		button.title = label;
		button.setAttribute("aria-label", label);
		const hint = document.createElement("div");
		hint.className = "ytpl-studio-hint";
		hint.setAttribute("role", "status");
		hint.hidden = true;
		let timer;
		const showHint = (message) => {
			hint.textContent = message;
			hint.hidden = false;
			if (timer) window.clearTimeout(timer);
			timer = window.setTimeout(() => {
				hint.hidden = true;
			}, 6e3);
		};
		button.addEventListener("click", async () => {
			try {
				const response = await browser.runtime.sendMessage({ type: "OPEN_SIDEBAR" });
				showHint(response?.ok ? t("studio.openHintOk") : t("studio.openHintFail"));
			} catch {
				showHint(t("studio.openHintFail"));
			}
		});
		shadow.appendChild(button);
		shadow.appendChild(hint);
		document.documentElement.appendChild(host);
	}
	mountStudioLauncher();
})();
