var ytpl_channel = (function(exports) {
	Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
	// node_modules/preact/dist/preact.mjs
	var n;
	var t$2;
	var i$1;
	var u$2;
	var f$2;
	var e$1;
	var o$2;
	var l$1;
	var c$1;
	var a$2;
	var h$1 = Symbol.for("pv");
	var p$1 = {};
	var v$1 = [];
	var y$1 = /^m(i|n|o|s|text|space)$/;
	var w$1 = Array.isArray;
	var d$1 = v$1.slice;
	var _$1 = Object.assign;
	function g$1(n) {
		n && n.parentNode && n.remove();
	}
	function m$1(r, i, u, f, e) {
		var o = {
			type: r,
			props: i,
			key: u,
			ref: f,
			__k: null,
			__: null,
			__b: 0,
			__e: null,
			__c: null,
			constructor: h$1,
			__v: e || ++t$2,
			__i: -1,
			__u: 0
		};
		return !e && n.vnode && n.vnode(o), o;
	}
	function M(n) {
		return n.children;
	}
	function x(n, t) {
		this.props = n, this.context = t, this.__g = 0;
	}
	function S(n, t) {
		if (null == t) return n.__ && S(n.__, n.__i + 1);
		for (var r; t < n.__k.length; t++) if ((r = n.__k[t]) && r.__e) return r.__e;
		return "function" != typeof n.type || n.props.__P ? null : S(n);
	}
	function C$1(n) {
		if ((n = n.__) && n.__c && !n.props.__P) return n.__e = null, n.__k.some(function(t) {
			return t && (n.__e = t.__e);
		}), C$1(n);
	}
	function j(t) {
		(8 & t.__g || (t.__g |= 8, i$1.push(t), f$2++)) && u$2 == n.debounceRendering || ((u$2 = n.debounceRendering) || queueMicrotask)(L);
	}
	function L() {
		var t, r, o, l, c, a, s, p, v;
		try {
			for (r = 1; i$1.length;) i$1.length > r && i$1.sort(e$1), t = i$1.shift(), r = i$1.length, 8 & t.__g && (l = void 0, c = void 0, a = (c = (o = t).__v).__e, s = [], p = [], (v = o.__P) && ((l = _$1({ constructor: h$1 }, c)).__v = c.__v + 1, n.vnode && n.vnode(l), V(v, l, c, o.__n, v.namespaceURI, 32 & c.__u ? [a] : null, s, a || S(c), 32 & c.__u, p), l.__v = c.__v, l.__.__k[l.__i] = l, D$1(s, l, p), c.__ = c.__e = null, l.__e != a && C$1(l)));
		} finally {
			(f$2 = i$1.length) && (u$2 || queueMicrotask)(L);
		}
	}
	function H(n, t, r, i, u, f, e, o, l, c, a) {
		var s, h, y, w, d, _, g = i.__k || v$1, k = t.length;
		for (l = I(r, t, g, l, k), s = 0; s < k; s++) null != (y = r.__k[s]) && (h = ~y.__i && g[y.__i] || p$1, y.__i = s, _ = V(n, y, h, u, f, e, o, l, c, a), w = y.__e, (h.ref != y.ref || 8 & h.__u) && (h.ref && F(h.ref, null, y, h), y.ref && a.push(y.ref, y.__c || w, y)), d = d || w, 4 & y.__u ? (l = q(y, l, n, !h.__v), h.__e && (h.__e = null)) : "function" == typeof y.type && void 0 !== _ ? l = _ : w && (l = w.nextSibling), y.__u &= -21);
		return r.__e = d, l;
	}
	function I(n, t, r, i, u) {
		var f, e, o, l, c, a, s, p, v, y = r.length, d = y, _ = 0, g = 0, k = n.__k = Array(u);
		for (f = 0; f < u; f++) null != (e = t[f]) && "boolean" != typeof e && "function" != typeof e ? ("object" != typeof e || e.constructor === String ? e = k[f] = m$1(null, e) : w$1(e) ? e = k[f] = m$1(M, { children: e }) : e.constructor === h$1 && e.__b ? e = k[f] = m$1(e.type, e.props, e.key, e.ref, e.__v) : k[f] = e, l = f + _, e.__ = n, e.__b = n.__b + 1, o = null, ~(c = e.__i = O(e, r, l, d)) && (d--, (o = r[c]) && (o.__u |= 2)), o && o.__v ? (e.__u |= 16, c == l - 1 ? _-- : c == l + 1 ? _++ : c != l && (c > l ? _-- : _++, g = 1)) : (~c || (u > y ? _-- : u < y && _++), "function" != typeof e.type && (e.__u |= 4))) : k[f] = null;
		if (g) {
			for (a = [], s = [], f = 0; f < u; f++) if ((e = k[f]) && 16 & e.__u) {
				for (_ = 0, p = a.length; _ < p;) a[v = _ + p >> 1] < e.__i ? _ = v + 1 : p = v;
				a[_] = e.__i, s[f] = _ + 1;
			}
			for (_ = a.length; f--;) s[f] && (s[f] == _ ? _-- : k[f].__u |= 4);
		}
		if (d) for (f = 0; f < y; f++) !(o = r[f]) || 2 & o.__u || (o.__e == i && (i = S(o)), G$1(o, o));
		return i;
	}
	function q(n, t, r, i) {
		var u, f, e, o;
		if ("function" == typeof n.type) {
			if (n.props.__P) return t;
			if (u = n.__k) for (f = 0; f < u.length; f++) u[f] && (u[f].__ = n, t = q(u[f], t, r, !1));
			return t;
		}
		for (t && !t.parentNode && (t = S(n)) && !t.parentNode && (t = null), e = n.__e, o = t; o && 8 == o.nodeType;) o = o.nextSibling;
		for (e != o && (!i && r.moveBefore && e.parentNode ? r.moveBefore(e, t) : r.insertBefore(e, t || null)), t = e; (t = t && t.nextSibling) && 8 == t.nodeType && !t.data.startsWith("$s"););
		return t;
	}
	function O(n, t, r, i) {
		var u, f = n.key, e = n.type, o = t[r], l = o && !(2 & o.__u);
		if (null === o && null == f || l && f == o.key && e == o.type) return r;
		if (i > (l ? 1 : 0)) {
			for (u = r - 1; u >= 0; u--) if ((o = t[u]) && !(2 & o.__u) && f == o.key && e == o.type) return u;
			for (u = r + 1; u < t.length; u++) if ((o = t[u]) && !(2 & o.__u) && f == o.key && e == o.type) return u;
		}
		return -1;
	}
	function P(n, t, r) {
		r ??= "", "-" == t[0] ? n.setProperty(t, r) : n[t] = r;
	}
	function T(n, t, r, i, u) {
		var f, e;
		if ("style" == t) if ("string" == typeof r) n.style.cssText = r;
		else {
			if ("string" == typeof i && (n.style.cssText = i = ""), i) for (t in i) r && t in r || P(n.style, t);
			if (r) for (t in r) i && r[t] == i[t] || P(n.style, t, r[t]);
		}
		else if ("o" == t[0] && "n" == t[1]) (n.__e || (n.__e = {}))[t] = r, r && i || (e = a$2[t] || (a$2[t] = N(t)), (n.__a || (n.__a = {}))[t] = c$1, f = t != (t = t.replace(l$1, "$1")), (t = t.slice(2))[0] < "a" && (t = t.toLowerCase()), r ? n.addEventListener(t, e, f) : n.removeEventListener(t, e, f));
		else {
			if ("http://www.w3.org/2000/svg" == u) t = t.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
			else if ("width" != t && "height" != t && "href" != t && "list" != t && "form" != t && "tabIndex" != t && "download" != t && "rowSpan" != t && "colSpan" != t && "role" != t && "popover" != t && t in n) try {
				n[t] = null == r ? "" : r;
				return;
			} catch (n) {}
			if ("function" == typeof r) return;
			null == r || !1 === r && "-" != t[4] ? n.removeAttribute(t) : n.setAttribute(t, "popover" == t && 1 == r ? "" : r);
		}
	}
	function N(t) {
		return function(r) {
			var i = this.__e;
			if (i) {
				if (i = i[t], null == r[o$2]) r[o$2] = c$1++;
				else if (r[o$2] < this.__a[t]) return;
				return i(n.event ? n.event(r) : r);
			}
		};
	}
	function V(t, r, i, u, f, e, o, l, c, a) {
		var s, p, y, d, k, b, m, $, C, j, L, I, q, A, O, P, T, N, V = r.type;
		if (r.constructor !== h$1) return null;
		128 & i.__u && (c = 32 & i.__u, s = i.__c.__z) && (r.__u |= c, p = e = [], 8 == s.nodeType ? l = z$1(s, e) : e.push(s), l = e[0] || l), (s = n.__b) && s(r);
		n: if ("function" == typeof V) {
			y = o.length;
			try {
				if ($ = r.props, C = (s = V.prototype) && s.render, j = (s = V.contextType) && u[s.__c], L = s ? j ? j.props.value : s.__ : u, (d = i.__c) ? (r.__c = d, 2 & d.__g && (d.__g |= 1)) : (C ? r.__c = d = new V($, L) : (r.__c = d = new x($, L), d.constructor = V, d.render = J), j && j.sub(d), d.state || (d.state = {}), d.__n = u, d.__g |= 8, d.__h = [], d.__k = []), C && (d.__s || (d.__s = d.state), V.getDerivedStateFromProps && (d.__s == d.state && (d.__s = _$1({}, d.__s)), _$1(d.__s, V.getDerivedStateFromProps($, d.__s)))), k = d.props, b = d.state, d.__v = r, i.__c) {
					if ($ !== k && C && !V.getDerivedStateFromProps && d.componentWillReceiveProps && d.componentWillReceiveProps($, L), r.__v == i.__v && !(8 & d.__g) || !(4 & d.__g) && d.shouldComponentUpdate && !1 === d.shouldComponentUpdate($, d.__s, L)) {
						r.__v != i.__v && (d.props = $, d.state = d.__s, d.__g &= -9), r.__e = i.__e, r.__k = i.__k, r.__k.some(function(n) {
							n && (n.__ = r);
						}), v$1.push.apply(d.__h, d.__k), d.__k = [], d.__h.length && o.push(d), l = S(i);
						break n;
					}
					d.componentWillUpdate && d.componentWillUpdate($, d.__s, L), C && d.componentDidUpdate && d.__h.push(function() {
						d.componentDidUpdate(k, b, m);
					});
				} else C && !V.getDerivedStateFromProps && d.componentWillMount && d.componentWillMount(), C && d.componentDidMount && d.__h.push(d.componentDidMount);
				if (d.context = L, d.props = $, d.__P = t, d.__g &= -5, I = n.__r, q = 0, C) d.state = d.__s, d.__g &= -9, I && I(r), s = d.render(d.props, d.state, d.context), v$1.push.apply(d.__h, d.__k), d.__k = [];
				else do
					d.__g &= -9, I && I(r), s = d.render(d.props, d.state, d.context), d.state = d.__s;
				while (8 & d.__g && ++q < 25);
				d.state = d.__s, d.getChildContext && (u = _$1({}, u, d.getChildContext())), C && i.__c && d.getSnapshotBeforeUpdate && (m = d.getSnapshotBeforeUpdate(k, b)), A = s && s.type === M && null == s.key ? s.props.children : s, $.__P && (s = l, f = (t = $.__P).namespaceURI, c = e = null, i.props && i.props.__P != t && (i.__k.some(function(n) {
					n && G$1(n, n);
				}), i.__k = null), l = i.__k ? S(i, 0) : null), l = H(t, w$1(A) ? A : [A], r, i, u, f, e, o, l, c, a), $.__P && (r.__e = null, l = s), r.__u &= -161, p && p.some(g$1), d.__h.length && o.push(d), 1 & d.__g && (d.__g &= -4);
			} catch (t) {
				if (o.length = y, r.__v = null, c || e) if (t.then) {
					if (O = 0, r.__u |= 128 | c, e) {
						for (~(T = e.indexOf(l || void 0)) || (T = e.length); (N = e[T - 1]) && 8 == N.nodeType;) T--;
						for (; T < e.length; T++) if (N = e[T]) {
							if (e[T] = null, 8 == N.nodeType) {
								if (N.data.startsWith("$s")) O++ || (P = N);
								else if (O && N.data.startsWith("/$s") && !--O) break;
							} else if (!O) break;
						}
					}
					if (!P) {
						for (; l && 8 == l.nodeType && l.nextSibling;) l = l.nextSibling;
						P = l;
					}
					(s = z$1(P = r.__c.__z || (r.__c.__z = P))) ? (r.__e = P, l = s) : r.__e = l, l = l && l.nextSibling;
				} else e && e.some(g$1);
				else r.__e = i.__e;
				r.__k || (r.__k = i.__k || []), t.then || B$1(r), n.__e(t, r, i);
			}
		} else l = r.__e = E$1(i.__e, r, i, u, f, e, o, c, a, t);
		return (s = n.diffed) && s(r), l;
	}
	function z$1(n, t) {
		if (n && 8 == n.nodeType && n.data.startsWith("$s")) for (var r = 1; n = n.nextSibling;) {
			if (8 == n.nodeType) {
				if (n.data.startsWith("$s")) r++;
				else if (n.data.startsWith("/$s") && !--r) return n;
			}
			t && t.push(n);
		}
	}
	function B$1(n) {
		n && (n.__c && (n.__c.__g |= 4), n.__k && n.__k.some(B$1));
	}
	function D$1(t, r, i) {
		for (var u = 0; u < i.length;) F(i[u++], i[u++], i[u++]);
		n.__c && n.__c(r, t), t.some(function(r) {
			try {
				t = r.__h, r.__h = [], t.some(function(n) {
					n.call(r);
				});
			} catch (t) {
				n.__e(t, r.__v);
			}
		});
	}
	function E$1(t, r, i, u, f, e, o, l, c, a) {
		var s, h, v, _, k, b, m, $, M, x = i.props || p$1, C = r.props, j = r.type;
		if ("svg" == j ? f = "http://www.w3.org/2000/svg" : "math" == j ? f = "http://www.w3.org/1998/Math/MathML" : f || (f = "http://www.w3.org/1999/xhtml"), e) {
			for (s = 0; s < e.length; s++) if ((k = e[s]) && (j ? k.localName == j : 3 == k.nodeType)) {
				t = k, e[s] = null;
				break;
			}
		}
		if (!t) {
			if ($ = a.ownerDocument || document, !j) return $.createTextNode(C);
			t = $.createElementNS(f, j, C.is && C), l && (n.__m && n.__m(r, e), l = !1), e = null;
		}
		if (j) {
			if (a = "template" == j && t.content || t, e = "textarea" == j && null != C.defaultValue ? null : e && d$1.call(a.childNodes), !l && e) for (x = {}, s = 0; s < t.attributes.length; s++) x[(k = t.attributes[s]).name] = k.value;
			for (s in x) k = x[s], "dangerouslySetInnerHTML" == s ? v = k : "children" == s || s in C || "value" == s && "defaultValue" in C || "checked" == s && "defaultChecked" in C || T(t, s, null, k, f);
			for (s in M = 1 & i.__u, C) k = C[s], "children" == s ? _ = k : "dangerouslySetInnerHTML" == s ? h = k : "value" == s ? b = k : "checked" == s ? m = k : l && "function" != typeof k || !(x[s] !== k || M && null != k) || T(t, s, k, x[s], f);
			h ? (l || v && (h.__html == v.__html || h.__html == t.innerHTML) || (t.innerHTML = h.__html), r.__k = []) : (v && (t.textContent = ""), ("foreignObject" == j || "http://www.w3.org/1998/Math/MathML" == f && y$1.test(j)) && (f = "http://www.w3.org/1999/xhtml"), H(a, w$1(_) ? _ : [_], r, i, u, f, e, o, e ? e[0] : i.__k && S(i, 0), l, c), e && e.some(g$1)), l && "textarea" != j || (s = "value", "progress" == j && null == b ? t.removeAttribute(s) : null == b || b === t[s] && ("progress" != j || b) || T(t, s, b, x[s], f), s = "checked", null != m && m != t[s] && T(t, s, m, x[s], f));
		} else x === C || l && t.data == C || (t.data = C);
		return t;
	}
	function F(t, r, i, u) {
		try {
			"function" == typeof t ? r ? r.__x = t(r) || 1 : u && (u = u.__c || u.__e) && (r = u.__x) && (u.__x = null, "function" == typeof r ? r() : t(null)) : t.current = r;
		} catch (t) {
			n.__e(t, i);
		}
	}
	function G$1(t, r, i) {
		var u, f, e, o;
		if (n.unmount && n.unmount(t), !(u = t.ref) || u.current && u.current != t.__e || F(u, null, r, t), u = t.__c) {
			if (u.componentWillUnmount) try {
				u.componentWillUnmount();
			} catch (t) {
				n.__e(t, r);
			}
			u.__P = u.__n = null;
		}
		if (u = t.__k) for (o = 0; o < u.length; o++) u[o] && G$1(u[o], r, "function" != typeof t.type || i && !t.props.__P);
		!i && (u = t.__c) && (u = u.__z) && (f = z$1(u, e = [])) && (u == t.__e && e.some(g$1), g$1(f), g$1(u)), (u = t.__e) && (i || g$1(u), u.__e && (u.__e = null)), t.__e = t.__c = t.__ = null;
	}
	function J(n, t, r) {
		return this.constructor(n, r);
	}
	function K(t, r) {
		var i, u, f, e;
		n.__ && n.__(t, r), 9 == r.nodeType && (r = r.documentElement), u = (i = t && 32 & t.__u) ? null : r.__k, r.__k = m$1(M, { children: [t] }), f = [], e = [], V(r, r.__k, u || p$1, p$1, r.namespaceURI, u ? null : r.firstChild ? d$1.call(r.childNodes) : null, f, u ? u.__e : r.firstChild, i, e), D$1(f, r.__k, e), r.__k.props.children = null;
	}
	n = { __e: function(n, t, r, i) {
		for (var u, e, o; t = t.__;) if ((u = t.__c) && !(1 & u.__g)) {
			u.__g |= 4;
			try {
				if ((o = (e = u.constructor) && e.getDerivedStateFromError) && u.setState(e.getDerivedStateFromError(n)), u.componentDidCatch && (u.componentDidCatch(n, i || {}), o = 1), o && 8 & u.__g) return void (u.__g |= 2);
			} catch (t) {
				n = t;
			}
		}
		throw f$2 = 0, n;
	} }, t$2 = 0, x.prototype.setState = function(n, t) {
		var r = this.__s;
		r && r != this.state || (r = this.__s = _$1({}, this.state)), "function" == typeof n && (n = n(_$1({}, r), this.props)), n && (_$1(r, n), this.__v && (t && this.__k.push(t), j(this)));
	}, x.prototype.forceUpdate = function(n) {
		this.__v && (this.__g |= 4, n && this.__h.push(n), j(this));
	}, x.prototype.render = M, i$1 = [], f$2 = 0, e$1 = function(n, t) {
		return n.__v.__b - t.__v.__b;
	}, o$2 = Symbol(), l$1 = /(PointerCapture)$|Capture$/i, c$1 = 0, a$2 = {};
	// node_modules/preact/hooks/dist/hooks.mjs
	var t$1;
	var r;
	var u$1;
	var i;
	var o$1 = Object.is;
	var f$1 = 0;
	var c = [];
	var e = [];
	var a$1 = n;
	var v = a$1.__b;
	var l = a$1.__r;
	var m = a$1.diffed;
	var h = a$1.__c;
	var s = a$1.unmount;
	var p = a$1.__;
	function y(n, t) {
		a$1.__h && a$1.__h(r, n, f$1 || t), f$1 = 0;
		var u = r.__H || (r.__H = {
			__: [],
			__h: []
		});
		return n >= u.__.length && u.__.push({}), u.__[n];
	}
	function d(n) {
		return f$1 = 1, _(G, n);
	}
	function _(n, u, i) {
		var f = y(t$1++, 2);
		if (f.t = n, !f.__c && (f.__ = [i ? i(u) : G(void 0, u), function(n) {
			var t = f.__N ? f.__N[0] : f.__[0], r = f.t(t, n);
			o$1(t, r) || (f.__N = [r, f.__[1]], f.__c.setState({}));
		}], f.__c = r, !r.__f)) {
			r.__f = !0;
			var c = r.shouldComponentUpdate;
			r.shouldComponentUpdate = function(n, t, r) {
				var u = this.__H;
				if (!u) return !0;
				var i = !1, f = this.props != n;
				if (u.__.some(function(n) {
					n.__N && (i = !0, o$1(n.__[0], n.__N[0]) || (f = !0));
				}), c) {
					var e = c.call(this, n, t, r);
					return i ? e || f : e;
				}
				return !i || f;
			};
		}
		return f.__;
	}
	function A(n, u) {
		var i = y(t$1++, 3);
		!a$1.__s && E(i.__H, u) && (i.__P = !0, i.__ = n, i.u = u, r.__H.__h.push(i));
	}
	function w(n, r) {
		var u = y(t$1++, 7);
		return E(u.__H, r) && (u.__ = n(), u.__H = r), u.__;
	}
	function b(n, t) {
		return f$1 = 8, w(function() {
			return n;
		}, t);
	}
	function g() {
		var n;
		do {
			for (; n = e.shift();) try {
				C(n);
			} catch (t) {
				a$1.__e(t, { __: (n = n.__P) && n.__v });
			}
			for (; n = c.shift();) {
				var t = n.__H;
				if (n.__P && t) try {
					t.__h.some(C), t.__h.some(D), t.__h = [];
				} catch (r) {
					t.__h = [], a$1.__e(r, n.__v);
				}
			}
		} while (e.length);
	}
	a$1.__b = function(n) {
		r = null, v && v(n);
	}, a$1.__ = function(n, t) {
		n && t.__k && t.__k.__m && (n.__m = t.__k.__m), p && p(n, t);
	}, a$1.__r = function(n) {
		l && l(n), t$1 = 0;
		var i = (r = n.__c).__H;
		i && (u$1 == r ? r.__h = [] : (i.__h.some(C), i.__h.some(D), t$1 = 0), i.__h = [], i.__.some(function(n) {
			n.__N && (n.__ = n.__N), n.u = n.__N = void 0;
		})), u$1 = r;
	}, a$1.diffed = function(n) {
		m && m(n);
		var t = n.__c;
		t && t.__H && (t.__H.__h.length && B(c.push(t)), t.__H.__.some(function(n) {
			n.u && (n.__H = n.u);
		})), u$1 = r = null;
	}, a$1.__c = function(n, t) {
		t.some(function(n) {
			try {
				n.__h.some(C), n.__h = n.__h.filter(function(n) {
					return !n.__ || D(n);
				});
			} catch (t) {
				n.__h = [function() {
					throw t;
				}];
			}
		}), h && h(n, t);
	}, a$1.unmount = function(n) {
		s && s(n);
		var t, r, u = n.__c;
		u && u.__H && (u.__H.__.some(function(u) {
			try {
				if (u.__P && u.__c) {
					if (void 0 === r) {
						for (r = n.__; r && (!r.__c || !r.__c.__P);) r = r.__;
						r = r && r.__c;
					}
					u.__P = r, B(e.push(u));
				} else C(u);
			} catch (n) {
				t = n;
			}
		}), u.__H = void 0, t && a$1.__e(t, u.__v));
	};
	var k = "function" == typeof requestAnimationFrame;
	function z(n) {
		var t, r = function() {
			clearTimeout(u), k && cancelAnimationFrame(t), setTimeout(n);
		}, u = setTimeout(r, 35);
		k && (t = requestAnimationFrame(r));
	}
	function B(n) {
		1 != n && i == a$1.requestAnimationFrame || ((i = a$1.requestAnimationFrame) || z)(g);
	}
	function C(n) {
		var t = r, u = n.__c;
		"function" == typeof u && (n.__c = void 0, u()), r = t;
	}
	function D(n) {
		var t = r;
		n.__c = n.__(), r = t;
	}
	function E(n, t) {
		return !n || n.length != t.length || t.some(function(t, r) {
			return !o$1(t, n[r]);
		});
	}
	function G(n, t) {
		return "function" == typeof t ? t(n) : t;
	}
	// src/core/i18n.ts
	function t(key, substitutions) {
		try {
			return browser.i18n.getMessage(key, substitutions) || key;
		} catch {
			return key;
		}
	}
	function uiLocale() {
		try {
			return browser.i18n.getUILanguage() || "en";
		} catch {
			return "en";
		}
	}
	// src/core/format.ts
	function formatCompact(value) {
		if (!Number.isFinite(value)) return "—";
		try {
			return new Intl.NumberFormat(uiLocale(), {
				notation: "compact",
				maximumFractionDigits: 1
			}).format(value);
		} catch {
			return String(Math.round(value));
		}
	}
	// src/core/settings.ts
	var DEFAULT_SETTINGS = {
		apiKey: "",
		showFloatingButton: true,
		keywordMode: "api"
	};
	async function getSettings() {
		try {
			const stored = await browser.storage.sync.get(DEFAULT_SETTINGS);
			return {
				apiKey: typeof stored.apiKey === "string" ? stored.apiKey : "",
				showFloatingButton: stored.showFloatingButton !== false,
				keywordMode: stored.keywordMode === "session" ? "session" : "api"
			};
		} catch {
			return { ...DEFAULT_SETTINGS };
		}
	}
	// src/content/channel-styles.ts
	var channelStyles = `
:host {
  all: initial;
}

.ytpl-fab,
.ytpl-panel,
.ytpl-panel * {
  box-sizing: border-box;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
}

.ytpl-fab {
  position: fixed;
  right: 18px;
  bottom: 18px;
  width: 48px;
  height: 48px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid #2a323d;
  border-radius: 50%;
  background: #0f1115;
  color: #22d3a6;
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.45);
  cursor: pointer;
  transition: transform 0.15s ease, border-color 0.15s ease;
  padding: 0;
}

.ytpl-fab:hover {
  transform: translateY(-1px);
  border-color: #22d3a6;
}

.ytpl-fab svg {
  width: 24px;
  height: 24px;
  display: block;
}

.ytpl-panel {
  position: fixed;
  right: 18px;
  bottom: 78px;
  width: 340px;
  max-width: calc(100vw - 36px);
  max-height: min(70vh, 560px);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: #0f1115;
  color: #e8edf4;
  border: 1px solid #2a323d;
  border-radius: 14px;
  box-shadow: 0 18px 48px rgba(0, 0, 0, 0.55);
  font-size: 13px;
  line-height: 1.45;
}

.ytpl-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 10px 12px;
  border-bottom: 1px solid #2a323d;
  background: #161a21;
}

.ytpl-head strong {
  font-size: 12px;
  font-weight: 600;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  color: #93a1b3;
}

.ytpl-body {
  padding: 12px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.ytpl-title {
  margin: 0;
  font-size: 14px;
  font-weight: 600;
  line-height: 1.35;
  color: #e8edf4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.ytpl-channel {
  margin: 4px 0 0;
  font-size: 12px;
  color: #93a1b3;
}

.ytpl-stats {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
}

.ytpl-stat {
  background: #161a21;
  border: 1px solid #2a323d;
  border-radius: 10px;
  padding: 8px;
  min-width: 0;
}

.ytpl-stat-label {
  display: block;
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: #93a1b3;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.ytpl-stat-value {
  display: block;
  margin-top: 2px;
  font-size: 14px;
  font-weight: 600;
  color: #e8edf4;
}

.ytpl-section-title {
  margin: 0 0 6px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: #93a1b3;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}

.ytpl-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.ytpl-tag {
  background: #1d232c;
  border: 1px solid #2a323d;
  border-radius: 999px;
  padding: 3px 9px;
  font-size: 11px;
  color: #c8d3e1;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ytpl-empty {
  margin: 0;
  color: #93a1b3;
  font-size: 12px;
}

.ytpl-foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 10px 12px;
  border-top: 1px solid #2a323d;
  background: #161a21;
}

.ytpl-link,
.ytpl-copy {
  appearance: none;
  border: 0;
  background: transparent;
  color: #22d3a6;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  padding: 0;
}

.ytpl-link:hover,
.ytpl-copy:hover {
  text-decoration: underline;
}

.ytpl-x {
  appearance: none;
  border: 0;
  background: transparent;
  color: #93a1b3;
  font-size: 18px;
  line-height: 1;
  cursor: pointer;
  padding: 2px 4px;
}

.ytpl-x:hover {
  color: #e8edf4;
}

.ytpl-muted {
  color: #93a1b3;
  font-size: 12px;
  margin: 0;
}

.ytpl-hint {
  margin: 0;
  padding: 7px 9px;
  border: 1px solid #4a3a1a;
  background: #241d0f;
  border-radius: 8px;
  color: #f5d58b;
  font-size: 11px;
  line-height: 1.4;
}

.ytpl-channel-head {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 10px 12px;
  background: #161a21;
  border: 1px solid #2a323d;
  border-radius: 10px;
}

.ytpl-channel-head strong {
  font-size: 13px;
  color: #e8edf4;
}

.ytpl-channel-head span {
  font-size: 11px;
  color: #93a1b3;
}

.ytpl-outlier-list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.ytpl-outlier {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 8px 9px;
  background: #161a21;
  border: 1px solid #2a323d;
  border-radius: 10px;
  text-decoration: none;
  color: inherit;
}

.ytpl-outlier:hover {
  border-color: #22d3a6;
}

.ytpl-rank {
  flex: 0 0 auto;
  width: 14px;
  padding-top: 2px;
  text-align: right;
  font-size: 10px;
  color: #93a1b3;
  font-variant-numeric: tabular-nums;
}

.ytpl-outlier-main {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.ytpl-outlier-title {
  font-size: 12px;
  line-height: 1.35;
  color: #e8edf4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.ytpl-outlier-meta {
  font-size: 10px;
  color: #93a1b3;
}

.ytpl-badge {
  flex: 0 0 auto;
  font-size: 11px;
  font-weight: 700;
  padding: 2px 7px;
  border-radius: 999px;
  background: #1d232c;
  border: 1px solid #2a323d;
  color: #93a1b3;
  font-variant-numeric: tabular-nums;
}

.ytpl-badge.is-hot {
  background: #34d399;
  border-color: #34d399;
  color: #0f1115;
}

.ytpl-badge.is-warm {
  background: rgba(34, 211, 166, 0.12);
  border-color: rgba(34, 211, 166, 0.4);
  color: #22d3a6;
}

.ytpl-note {
  margin: 0;
  font-size: 11px;
  line-height: 1.4;
  color: #93a1b3;
}
`;
	// node_modules/preact/jsx-runtime/dist/jsxRuntime.mjs
	var f = Symbol.for("pv");
	var o = 0;
	Array.isArray;
	function a(t, e, n$1, u, a, i) {
		e || (e = {});
		var c, l, p = e;
		if ("ref" in p && "function" != typeof t) for (l in p = {}, e) "ref" == l ? c = e[l] : p[l] = e[l];
		var s = {
			type: t,
			props: p,
			key: n$1,
			ref: c,
			__k: null,
			__: null,
			__b: 0,
			__e: null,
			__c: null,
			constructor: f,
			__v: --o,
			__i: -1,
			__u: 0
		};
		return (a || i) && (s.__source = a, s.__self = i), n.vnode && n.vnode(s), s;
	}
	// src/content/channel.tsx
	var invalidate = null;
	function notifyChannelChanged() {
		invalidate?.();
	}
	function ChartIcon() {
		return /* @__PURE__ */ a("svg", {
			viewBox: "0 0 24 24",
			fill: "none",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ a("path", {
					d: "M5 19V13",
					stroke: "currentColor",
					"stroke-width": "2",
					"stroke-linecap": "round"
				}),
				/* @__PURE__ */ a("path", {
					d: "M10 19V9",
					stroke: "currentColor",
					"stroke-width": "2",
					"stroke-linecap": "round"
				}),
				/* @__PURE__ */ a("path", {
					d: "M15 19V5",
					stroke: "currentColor",
					"stroke-width": "2",
					"stroke-linecap": "round"
				}),
				/* @__PURE__ */ a("path", {
					d: "M20 19V11",
					stroke: "currentColor",
					"stroke-width": "2",
					"stroke-linecap": "round"
				})
			]
		});
	}
	function badgeClass(outlier) {
		if (outlier >= 2) return "ytpl-badge is-hot";
		if (outlier >= 1.2) return "ytpl-badge is-warm";
		return "ytpl-badge";
	}
	function OutlierBody({ data }) {
		return /* @__PURE__ */ a(M, { children: [
			/* @__PURE__ */ a("div", {
				class: "ytpl-channel-head",
				children: [
					/* @__PURE__ */ a("strong", { children: data.channelName || "—" }),
					/* @__PURE__ */ a("span", { children: [
						t("outliers.median"),
						": ",
						formatCompact(data.medianViews)
					] }),
					/* @__PURE__ */ a("span", { children: t("outliers.sample", [String(data.sampleSize)]) })
				]
			}),
			data.videos.length === 0 ? /* @__PURE__ */ a("p", {
				class: "ytpl-muted",
				children: t("outliers.empty")
			}) : /* @__PURE__ */ a("ol", {
				class: "ytpl-outlier-list",
				children: data.videos.map((video, index) => /* @__PURE__ */ a("li", { children: /* @__PURE__ */ a("a", {
					class: "ytpl-outlier",
					href: `/watch?v=${video.videoId}`,
					target: "_blank",
					rel: "noopener noreferrer",
					children: [
						/* @__PURE__ */ a("span", {
							class: "ytpl-rank",
							children: index + 1
						}),
						/* @__PURE__ */ a("span", {
							class: "ytpl-outlier-main",
							children: [/* @__PURE__ */ a("span", {
								class: "ytpl-outlier-title",
								children: video.title
							}), /* @__PURE__ */ a("span", {
								class: "ytpl-outlier-meta",
								children: formatCompact(video.views)
							})]
						}),
						/* @__PURE__ */ a("span", {
							class: badgeClass(video.outlier),
							children: [video.outlier.toFixed(1), "x"]
						})
					]
				}) }, video.videoId))
			}),
			/* @__PURE__ */ a("p", {
				class: "ytpl-note",
				children: t("outliers.hint")
			})
		] });
	}
	function ChannelPanel() {
		const [open, setOpen] = d(false);
		const [data, setData] = d(null);
		const [status, setStatus] = d("idle");
		const load = b(async () => {
			setStatus("loading");
			try {
				const response = await browser.runtime.sendMessage({ type: "GET_CHANNEL_OUTLIERS" });
				if (response?.ok && response.data) {
					setData(response.data);
					setStatus("idle");
				} else {
					setData(null);
					setStatus("error");
				}
			} catch {
				setData(null);
				setStatus("error");
			}
		}, []);
		A(() => {
			invalidate = () => {
				if (open) load();
			};
			return () => {
				invalidate = null;
			};
		}, [open, load]);
		const toggle = () => {
			const next = !open;
			setOpen(next);
			if (next) load();
		};
		return /* @__PURE__ */ a(M, { children: [/* @__PURE__ */ a("button", {
			type: "button",
			class: "ytpl-fab",
			title: t("outliers.fab"),
			"aria-label": t("outliers.fab"),
			"aria-expanded": open,
			onClick: toggle,
			children: /* @__PURE__ */ a(ChartIcon, {})
		}), open && /* @__PURE__ */ a("section", {
			class: "ytpl-panel",
			role: "dialog",
			"aria-label": t("outliers.heading"),
			children: [
				/* @__PURE__ */ a("header", {
					class: "ytpl-head",
					children: [/* @__PURE__ */ a("strong", { children: t("outliers.heading") }), /* @__PURE__ */ a("button", {
						type: "button",
						class: "ytpl-x",
						"aria-label": t("ui.close"),
						onClick: () => setOpen(false),
						children: "×"
					})]
				}),
				/* @__PURE__ */ a("div", {
					class: "ytpl-body",
					children: [
						status === "loading" && /* @__PURE__ */ a("p", {
							class: "ytpl-muted",
							children: t("outliers.loading")
						}),
						status === "error" && /* @__PURE__ */ a("p", {
							class: "ytpl-muted",
							children: t("outliers.error")
						}),
						status === "idle" && data && /* @__PURE__ */ a(OutlierBody, { data })
					]
				}),
				/* @__PURE__ */ a("footer", {
					class: "ytpl-foot",
					children: [/* @__PURE__ */ a("button", {
						type: "button",
						class: "ytpl-link",
						onClick: () => void load(),
						children: t("outliers.refresh")
					}), /* @__PURE__ */ a("button", {
						type: "button",
						class: "ytpl-link",
						onClick: () => setOpen(false),
						children: t("ui.close")
					})]
				})
			]
		})] });
	}
	var host = null;
	var mounted = false;
	var visible = false;
	var lastHref = location.href;
	function isChannelPage() {
		return /^\/(@[^/]+|channel\/UC[\w-]{22}|c\/[^/]+|user\/[^/]+)(\/|$)/.test(location.pathname);
	}
	function ensureMounted() {
		if (mounted) return;
		mounted = true;
		host = document.createElement("div");
		host.id = "ytpl-channel-host";
		host.style.cssText = "all:initial;position:fixed;right:0;bottom:0;width:0;height:0;z-index:2147483000;";
		const shadow = host.attachShadow({ mode: "open" });
		try {
			const sheet = new CSSStyleSheet();
			sheet.replaceSync(channelStyles);
			shadow.adoptedStyleSheets = [sheet];
		} catch {
			const style = document.createElement("style");
			style.textContent = channelStyles;
			shadow.appendChild(style);
		}
		const mountPoint = document.createElement("div");
		shadow.appendChild(mountPoint);
		document.documentElement.appendChild(host);
		K(/* @__PURE__ */ a(ChannelPanel, {}), mountPoint);
	}
	async function sync() {
		if (!(await getSettings()).showFloatingButton || !isChannelPage()) {
			if (host) host.style.display = "none";
			visible = false;
			return;
		}
		ensureMounted();
		visible = true;
		if (host) host.style.display = "block";
	}
	function onPossibleNavigation() {
		if (location.href === lastHref) return;
		lastHref = location.href;
		sync();
		if (visible) notifyChannelChanged();
	}
	document.addEventListener("yt-navigate-finish", onPossibleNavigation, true);
	window.addEventListener("popstate", onPossibleNavigation);
	if (document.head) new MutationObserver(onPossibleNavigation).observe(document.head, {
		childList: true,
		subtree: true,
		characterData: true
	});
	browser.storage.onChanged.addListener((_changes, area) => {
		if (area === "sync") sync();
	});
	sync();
	exports.ChannelPanel = ChannelPanel;
	exports.notifyChannelChanged = notifyChannelChanged;
	return exports;
})({});
